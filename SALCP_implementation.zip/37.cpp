// Link: http://poj.org/problem?id=3261

#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

#define ll long long
#define lc (node << 1) + 1
#define rc (node << 1) + 2
#define endl '\n'
#define INF 1e9

const int max_n = 1e5 + 1;
const char first = 'a' - 1;
int n;
string s;

int lcp[max_n];
int p[max_n], c[max_n], pn[max_n], cn[max_n], cnt[max_n]; // p is the order, c is the rank

void suffix_array()
{
    // start by sorting the first layer of the numbers
    for (int i = 0; i < n; i++)
    {
        cnt[s[i] - first]++;
    }
    for (int i = 1; i < 27; i++)
    {
        cnt[i] += cnt[i - 1];
    }
    for (int i = 0; i < n; i++)
    {
        p[--cnt[s[i] - first]] = i;
    }
    c[p[0]] = 0;
    int classes = 1;
    for (int i = 1; i < n; i++)
    {
        if (s[p[i]] != s[p[i - 1]])
            classes++;
        c[p[i]] = classes - 1;
    }
    fill(cnt, cnt + 27, 0);

    for (int k = 0; (1 << k) < n; k++)
    {

        for (int i = 0; i < n; i++)
        {
            pn[i] = p[i] - (1 << k);
            if (pn[i] < 0)
                pn[i] += n;
        }

        fill(cnt, cnt + classes, 0);
        for (int i = 0; i < n; i++)
        {
            cnt[c[i]]++;
        }
        for (int i = 1; i < n; i++)
        {
            cnt[i] += cnt[i - 1];
        }
        for (int i = n - 1; i >= 0; i--)
        {
            p[--cnt[c[pn[i]]]] = pn[i];
        }

        cn[p[0]] = 0;
        classes = 1;
        for (int i = 1; i < n; i++)
        {
            pair<int, int> curr(c[p[i]], c[(p[i] + (1 << k)) % n]);
            pair<int, int> prev(c[p[i - 1]], c[(p[i - 1] + (1 << k)) % n]);
            if (curr != prev)
                classes++;
            cn[p[i]] = classes - 1;
        }

        for (int i = 0; i < n; i++)
        {
            c[i] = cn[i];
        }
    }
}

int r[max_n];
void longest_common_prefix()
{
    for (int i = 0; i < n; i++)
    {
        r[p[i]] = i; // ranking based on the lengths (decreasing)
    }

    int k = 0;
    for (int i = 0; i < n; i++)
    { // this is currently processing the ith largest suffix
        int curr = r[i];
        if (curr == n - 1)
        {
            k = 0;
            lcp[curr] = 0;
            continue;
        }
        int j = p[curr + 1];
        while (i + k < n && j + k < n && s[i + k] == s[j + k])
        {
            k++;
        }
        lcp[curr] = k;
        if (k)
            k--; // moving on to next transition
    }
}

int main()
{

    // cin.tie(0);
    // ios::sync_with_stdio(0);

    cin >> s;
    n = s.size();

    s += first;
    n++;

    suffix_array();
    longest_common_prefix();

    int ans = 0;
    int start_pos = 0;

    for (int i = 0; i < n - 1; i++)
    {
        if (lcp[i] > ans)
        {
            ans = lcp[i];
            start_pos = p[i];
        }
    }

    if (ans == 0)
        cout << -1 << endl;
    else
        cout << s.substr(start_pos, ans) << endl;

    return 0;
}
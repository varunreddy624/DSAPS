#include <bits/stdc++.h>
#define pb push_back
using namespace std;
array<int, 100004> SA, RNK, F, L;
array<vector<int>, 100004> buk;
void sort(array<int, 100004> &A, int n)
{
    int cnt = 0;
    for (int i = 0; i < n; i++)
    {
        buk[A[SA[i]]].pb(SA[i]);
    }
    for (int i = 0; i < max(n, 26); i++)
    {
        for (int x : buk[i])
        {
            SA[cnt++] = x;
        }
        buk[i].clear();
    }
}
void suf(string &S)
{
    int n = S.size(), cnt = -1, ff = -1, ll = -1;
    for (int i = 0; i < n; i++)
    {
        SA[i] = n - i - 1;
        F[i] = S[i] - 'a';
    }
    sort(F, n);
    for (int i = 0; i < n; i++)
    {
        if (F[SA[i]] == ff && L[SA[i]] == ll)
            RNK[SA[i]] = cnt;
        else
            RNK[SA[i]] = ++cnt;
        ff = F[SA[i]], ll = L[SA[i]];
    }
    for (int j = 1; j < n; j <<= 1)
    {
        cnt = ll = ff = -1;
        for (int i = 0; i < n; i++)
        {
            F[i] = RNK[i];
            L[i] = i + j < n ? RNK[i + j] : 0;
        }
        sort(L, n);
        sort(F, n);
        for (int i = 0; i < n; i++)
        {
            if (F[SA[i]] == ff && L[SA[i]] == ll)
                RNK[SA[i]] = cnt;
            else
                RNK[SA[i]] = ++cnt;
            ff = F[SA[i]], ll = L[SA[i]];
        }
    }
}
string lcp(string &S)
{
    int n = S.size(), cp = 0, k, lng = 0, ans;
    for (int i = 0; i < n; i++)
    {
        RNK[SA[i]] = i;
    }
    for (int i = 0; i < n; i++)
    {
        if (!RNK[i])
            continue;
        k = SA[RNK[i] - 1];
        if (cp)
            cp--;
        while (S[i + cp] == S[k + cp])
            cp++;
        if (cp > lng)
        {
            lng = cp;
            ans = i;
        }
    }
    if (!lng)
        return "-1";
    return S.substr(ans, lng);
}
signed main()
{
    string S;
    cin >> S;
    suf(S);
    cout << lcp(S);
    return 0;
}
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
struct th
{
    int x;
    int y;
    int ind;
};
string s, s1, s2;
int k, n, r, l, mi, mx = 0, x;
vector<vector<int>> rnk(19, vector<int>(262144));
vector<int> suf(131072);
void sort(vector<th> &vec)
{
    vector<th> v(n);
    vector<int> c1(n, 0), c2(n, 0);
    for (int i = 0; i < n; i++)
    {
        c1[vec[i].y]++;
        c2[vec[i].x]++;
    }
    for (int i = 1; i < n; i++)
        c1[i] += c1[i - 1], c2[i] += c2[i - 1];
    for (int i = n - 1; i >= 0; i--)
        v[--c1[vec[i].y]] = vec[i];
    for (int i = n - 1; i >= 0; i--)
        vec[--c2[v[i].x]] = v[i];
}
void build(string s)
{
    l = s.length();
    k = 1;
    n = 2;
    while (n - 1 < l)
        n *= 2, k++;
    for (int i = l; i < n; i++)
        s += '$';
    vector<pair<int, int>> v(n);
    for (int i = 0; i < n; i++)
        v[i] = {s[i], i};
    sort(v.begin(), v.end());
    rnk[0][v[0].second] = 0;
    for (int i = 1; i < n; i++)
        rnk[0][v[i].second] = rnk[0][v[i - 1].second] + ((v[i].first == v[i - 1].first) ? 0 : 1);
    vector<th> vec(n);
    for (int i = 1, r = 2; i <= k; i++, r *= 2)
    {
        for (int j = 0; j < n; j++)
        {
            vec[j] = {rnk[i - 1][j], rnk[i - 1][(j + r / 2) % n], j};
        }
        sort(vec);
        rnk[i][vec[0].ind] = 0;
        for (int j = 1; j < n; j++)
        {
            rnk[i][vec[j].ind] = rnk[i][vec[j - 1].ind] + ((vec[j].x == vec[j - 1].x && vec[j].y == vec[j - 1].y) ? 0 : 1);
        }
    }
    for (int i = 0; i < l; i++)
        suf[rnk[k][i] + l - n] = i;
}
int lcp(int i, int j)
{
    int ret = 0;
    for (int h = k; h >= 0 && i < l && j < l; h--)
    {
        if (i + (1 << h) <= l && j + (1 << h) <= l && rnk[h][i] == rnk[h][j])
        {
            i += (1 << h);
            j += (1 << h);
            ret += (1 << h);
        }
    }
    return ret;
}
int main()
{
    cin >> s;
    build(s);
    /*for(int i=0;i<l;i++){
        cout<<suf[i]<<' '<<s.substr(suf[i])<<'\n';
    }*/
    for (int i = 1; i < l; i++)
    {
        x = lcp(suf[i - 1], suf[i]);
        if (x > mx)
            mi = suf[i], mx = x;
    }
    cout << (!mx ? "-1" : s.substr(mi, mx));
}
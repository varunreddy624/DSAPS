#include <bits/stdc++.h>
#define fi first
#define se second
//
#define forr(i, a, b) for (int i = a; i <= b; ++i)
#define ford(i, b, a) for (int i = b; i >= a; --i)
#define fors(i, s, x, y, st) for (ll i = s; x <= y; i += st)
#define FORE(i, s, l) for (int i = s; i < (int)l; ++i)
//
#define ret return
#define BB (long double)
#define II (int)
#define MASK(N) (1ll << (N))
#define getbit(x, i) (((x) >> (i)) & 1)
//
#define all(v) (v).begin(), (v).end()
#define pub push_back
#define resz resize
#define SIZ(v) (int)(v).size()
//
#define ALL(a, s, t) (a) + (s), (a) + (t) + 1
#define UPB upper_bound
#define LWB lower_bound
///
using namespace std;
typedef pair<int, int> pii;
typedef long long ll;
const ll infll = 1e18 + 0x3f;
const int nmax = (5e5 + 9);
const int BOmax = (5e5 + 9);
///

struct suffix
{
    int index = 0;
    int r = 0;
    int nr = 0;
};
#define NextR tmp
#define post tmp
#define NewR tmp
#define thutu tmp
struct SuffixArray
{
    suffix sa[nmax];
    int n;
    int tmp[nmax];
    // NextR;
    void fillnextrank(int k)
    {
        forr(i, 1, n) NextR[sa[i].index] = sa[i].r;
        forr(i, 1, n)
        {
            int p = sa[i].index + k / 2;
            if (p <= n)
                sa[i].nr = NextR[p];
            else
                sa[i].nr = 0;
        }
    }
    queue<pair<suffix, int>> MO[nmax];
    int maxv;
    // post;
    void getMO()
    {
        int i = 1;
        while (i <= n)
        {
            post[i] = i;
            int j = i;
            while (j <= n && sa[j].r == sa[i].r)
            {
                int v = sa[j].nr;
                maxv = max(maxv, v);
                MO[v].push({sa[j], i});
                j++;
            }
            i = j;
        }
    }
    void Sort()
    {
        maxv = 0;
        getMO();
        forr(v, 0, maxv)
        {
            while (!MO[v].empty())
            {
                auto pp = MO[v].front();
                MO[v].pop();
                sa[post[pp.se]] = pp.fi;
                post[pp.se]++;
            }
        }
    }
    // NewR;
    bool giong(const suffix &a, const suffix &b)
    {
        if (a.r == b.r && a.nr == b.nr)
            ret true;
        ret false;
    }
    void stander()
    {
        NewR[1] = 1;
        forr(i, 2, n) if (giong(sa[i], sa[i - 1])) NewR[i] = NewR[i - 1];
        else NewR[i] = NewR[i - 1] + 1;
        forr(i, 1, n) sa[i].r = NewR[i];
    }
    void process(string &s)
    {
        n = s.size();
        s = " " + s;

        forr(i, 1, n) if (i == n) sa[i] = {i, II s[i], 0};
        else sa[i] = {i, II s[i], II s[i + 1]};
        sort(ALL(sa, 1, n), [&](const suffix &x, const suffix &y)
             { ret(x.r < y.r || (x.r == y.r && x.nr < y.nr)); });
        stander();

        int k = 2;
        while (k <= n)
        {
            k *= 2;
            fillnextrank(k);
            Sort();
            stander();
        }
    }
    int lcp[nmax];
    void buildlcp(const string &s)
    {
        forr(i, 1, n) thutu[sa[i].index] = i;
        int k = 0;
        forr(i, 1, n)
        {
            int t = thutu[i];
            int a = i + k;
            int b = sa[t - 1].index + k; // phan huong xai;
            while (a <= n && b <= n && s[a] == s[b])
            {
                k++;
                a++;
                b++;
            } // phan co them;
            lcp[t] = k;
            if (k > 0)
                k--; // thang sau chi duoc huong xai k-1 tu thang truoc do ma thoi;
        }
    }
} sa;

int n;
string s;

#define BAITOAN "A"
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    //freopen( BAITOAN ".INP","r",stdin );
    //freopen( BAITOAN ".OUT","w",stdout );

    cin >> s;
    n = s.size();
    sa.process(s);
    sa.buildlcp(s);

    //    cerr << s << endl;
    //    forr( i, 1, n )
    //    {
    //        cerr << sa.sa[i].index <<" : ";
    //        forr( j, sa.sa[i].index, n ) cerr << s[j]; cerr << endl;
    //        cerr << sa.lcp[i] << endl;
    //    }

    int leng = 0;
    int post = 0;
    forr(i, 1, n)
    {
        if (sa.lcp[i] > leng)
        {
            leng = sa.lcp[i];
            post = sa.sa[i].index;
        }
    }

    if (leng == 0)
    {
        cout << -1;
        ret 0;
    }
    forr(i, post, post + leng - 1) cout << s[i];

    return 0;
}
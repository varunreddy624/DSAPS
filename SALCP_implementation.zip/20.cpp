*Khangnh's code

    "You can either experience the pain of discipline or the pain of regret. 
    The choice is yours."
    * /

// - Only when necessary :d
// #pragma GCC optimize("Ofast")
// #pragma GCC optimize("unroll-loops")
// #pragma GCC target("avx,avx2,fma")

#include <bits/stdc++.h>
    using namespace std;

#define fileopen(a, b)                                 \
    freopen(((string)a + ".inp").c_str(), "r", stdin); \
    freopen(((string)b + ".out").c_str(), "w", stdout);

#define ll long long
// #define int long long
#define ld long double
#define fi first
#define se second
#define pb push_back
#define pf push_front
#define pob pop_back
#define pof pop_front
#define eb emplace_back
typedef pair<int, int> pii;

const int mod = 1e9 + 7;
const int inf = 0x3f3f3f3f;
const double pi = acos(-1);
const double eps = 1e-9;

struct sa
{
    string s;
    int n, logn;
    int p[25][100005], c[25][100005], cnt[100005];
    int lcp[100005];

    void init(const string &s)
    {
        this->s = s + "$";
        n = s.size() + 1;
        logn = 0;
        while ((1 << logn) < n)
            ++logn;

        build();
        build_lcp();
    }

    void build()
    {
        memset(cnt, 0, sizeof(cnt));
        for (int i = 0; i < n; ++i)
            ++cnt[s[i]];
        for (int i = 1; i < 256; ++i)
            cnt[i] += cnt[i - 1];
        for (int i = n - 1; i >= 0; --i)
            p[0][--cnt[s[i]]] = i;

        int classes = 0;
        c[0][p[0][0]] = 0;
        for (int i = 1; i < n; ++i)
        {
            if (s[p[0][i]] != s[p[0][i - 1]])
                ++classes;
            c[0][p[0][i]] = classes;
        }

        for (int iter = 1; iter <= logn; ++iter)
        {
            int half = (1 << (iter - 1));

            memset(cnt, 0, sizeof(cnt));
            for (int i = 0; i < n; ++i)
            {
                int le = p[iter - 1][i] - half;
                if (le < 0)
                    le += n;
                ++cnt[c[iter - 1][le]];
            }
            for (int i = 1; i < n; ++i)
                cnt[i] += cnt[i - 1];
            for (int i = n - 1; i >= 0; --i)
            {
                int le = p[iter - 1][i] - half;
                if (le < 0)
                    le += n;
                p[iter][--cnt[c[iter - 1][le]]] = le;
            }

            int classes = 0;
            c[iter][p[iter][0]] = 0;
            for (int i = 1; i < n; ++i)
            {
                int le1 = p[iter][i],
                    ri1 = le1 + half,
                    le2 = p[iter][i - 1],
                    ri2 = le2 + half;
                if (ri1 >= n)
                    ri1 -= n;
                if (ri2 >= n)
                    ri2 -= n;

                pii cur = {c[iter - 1][le1], c[iter - 1][ri1]},
                    lst = {c[iter - 1][le2], c[iter - 1][ri2]};
                if (cur != lst)
                    ++classes;
                c[iter][le1] = classes;
            }
        }
    }

    void build_lcp()
    {
        int k = 0;
        for (int i = 0; i < n; ++i)
        {
            if (c[logn][i] == n - 1)
            {
                k = 0;
                continue;
            }

            int j = p[logn][c[logn][i] + 1];
            while (i + k < n && j + k < n && s[i + k] == s[j + k])
                ++k;
            lcp[c[logn][i]] = (k ? k-- : 0);
        }
    }
} ds;

string s;
pii ans = {-1, 0};

void solve()
{
    cin >> s;
    ds.init(s);

    for (int i = 0; i < ds.n - 1; ++i)
    {
        if (ans.se < ds.lcp[i])
        {
            ans.se = ds.lcp[i];
            ans.fi = ds.p[ds.logn][i];
        }
    }

    cout << (ans.fi == -1 ? "-1" : ds.s.substr(ans.fi, ans.se));
}

signed main()
{
#ifdef LOCAL
    fileopen("input", "output");
    auto start = clock();
#endif
#ifndef LOCAL
    //		fileopen("LAH", "LAH");
#endif
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int test = 1;
    //	cin >> test;
    for (int tc = 1; tc <= test; ++tc)
        solve();
#ifdef LOCAL
    auto end = clock();
    cout << "\n\nExecution time : " << double(end - start) / CLOCKS_PER_SEC << "[s]";
#endif
    return 0;
}
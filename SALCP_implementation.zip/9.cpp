#include <bits/stdc++.h>

using namespace std;

#define print_op(...) ostream &operator<<(ostream &out, const __VA_ARGS__ &u)
template <typename A, typename B>
print_op(pair<A, B>)
{
    return out << "(" << u.first << ", " << u.second << ")";
}
template <typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type>
print_op(T_container)
{
    out << "{";
    string sep;
    for (const T &x : u)
        out << sep << x, sep = ", ";
    return out << "}";
}
template <typename T>
void dbg_out(string s, T x) { cerr << "\033[1;35m" << s << "\033[0;32m = \033[33m" << x << "\033[0m\n"; }
template <typename T, typename... Args>
void dbg_out(string s, T x, Args... args)
{
    for (int i = 0, b = 0; i < (int)s.size(); i++)
        if (s[i] == '(' || s[i] == '{')
            b++;
        else if (s[i] == ')' || s[i] == '}')
            b--;
        else if (s[i] == ',' && b == 0)
        {
            cerr << "\033[1;35m" << s.substr(0, i) << "\033[0;32m = \033[33m" << x << "\033[31m | ";
            dbg_out(s.substr(s.find_first_not_of(' ', i + 1)), args...);
            break;
        }
}
#ifdef LOCAL
#define dbg(...) dbg_out(#__VA_ARGS__, __VA_ARGS__)
#else
#define dbg(...)
#endif

#define ar array
#define ll long long
#define ld long double
#define sz(x) ((int)x.size())
#define rep(i, a, b) for (int i = (int)(a); i < (int)(b); i++)
#define all(a) (a).begin(), (a).end()

const int MAX_N = 1e5 + 5;
const int MAX_L = 20;
const int MAX_C = 26;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;

struct SuffixArray
{
    const int ALPHA = 256;
    int n;
    string s;
    vector<int> p, lcp;

    SuffixArray(const string &_s) : n((int)_s.length() + 1), s(_s), p(n), lcp(n - 1)
    {
        s += '$';
        buildSA();
        buildLCP();
    }

    void buildSA()
    {
        vector<int> c(n), cnt(max(ALPHA, n));
        for (int i = 0; i < n; i++)
            cnt[s[i]]++;
        for (int i = 1; i < ALPHA; i++)
            cnt[i] += cnt[i - 1];
        for (int i = 0; i < n; i++)
            p[--cnt[s[i]]] = i;
        c[p[0]] = 0;
        int classes = 1;
        for (int i = 1; i < n; i++)
        {
            if (s[p[i]] != s[p[i - 1]])
                classes++;
            c[p[i]] = classes - 1;
        }

        vector<int> pn(n), cn(n);
        for (int j = 0; 1 << j < n; j++)
        {
            for (int i = 0; i < n; i++)
            {
                pn[i] = p[i] - (1 << j);
                if (pn[i] < 0)
                    pn[i] += n;
            }
            fill(cnt.begin(), cnt.begin() + classes, 0);
            for (int i = 0; i < n; i++)
                cnt[c[pn[i]]]++;
            for (int i = 1; i < classes; i++)
                cnt[i] += cnt[i - 1];
            for (int i = n - 1; i >= 0; i--)
                p[--cnt[c[pn[i]]]] = pn[i];
            cn[p[0]] = 0;
            classes = 1;
            for (int i = 1; i < n; i++)
            {
                pair<int, int> cur(c[p[i]], c[(p[i] + (1 << j)) % n]), pre(c[p[i - 1]], c[(p[i - 1] + (1 << j)) % n]);
                if (cur != pre)
                    classes++;
                cn[p[i]] = classes - 1;
            }
            c.swap(cn);
        }
    }

    void buildLCP()
    {
        vector<int> rk(n);
        for (int i = 0; i < n; i++)
            rk[p[i]] = i;

        int k = 0;
        for (int i = 0; i < n; i++)
        {
            if (rk[i] == n - 1)
            {
                k = 0;
                continue;
            }
            int j = p[rk[i] + 1];
            while (i + k < n && j + k < n && s[i + k] == s[j + k])
                k++;
            lcp[rk[i]] = k;
            if (k)
                k--;
        }
    }
};

void solve(int tc = 0)
{
    string s;
    cin >> s;
    SuffixArray sa(s);
    int mx = 0;
    for (int i = 0; i < sz(sa.lcp); i++)
    {
        if (sa.lcp[i] > sa.lcp[mx])
        {
            mx = i;
        }
    }
    if (sa.lcp[mx] == 0)
    {
        cout << -1 << "\n";
        return;
    }
    cout << s.substr(sa.p[mx], sa.lcp[mx]) << "\n";
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int tc = 1;
    // cin >> tc;
    for (int t = 1; t <= tc; t++)
    {
        // cout << "Case #" << t << ": ";
        solve(t);
    }
}
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define vi vector<int>
#define ii pair<int, int>
#define mii map<int, int>
#define inf 1e18
#define maxpq priority_queue<int>
#define minpq priority_queue<int, vi, greater<int>>
#define mod 1e9 + 7

void countingSort(vi &sa, vi &c)
{
    int n = sa.size();
    vi cnt(n, 0);
    for (int i = 0; i < n; i++)
        cnt[c[i]]++;
    vi pos(n);
    pos[0] = 0;
    for (int i = 1; i < n; i++)
    {
        pos[i] = pos[i - 1] + cnt[i - 1];
    }
    vi new_sa(n);
    for (auto x : sa)
    {
        int i = c[x];
        new_sa[pos[i]] = x;
        pos[i]++;
    }
    sa = new_sa;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    string s;
    cin >> s;
    s += "$";
    int n = s.size();
    vi sa(n), c(n);
    vector<ii> order(n);
    for (int i = 0; i < n; i++)
        order[i] = {s[i], i};
    sort(order.begin(), order.end());
    for (int i = 0; i < n; i++)
        sa[i] = order[i].second;
    c[sa[0]] = 0;
    for (int i = 1; i < n; i++)
    {
        if (s[sa[i]] == s[sa[i - 1]])
            c[sa[i]] = c[sa[i - 1]];
        else
            c[sa[i]] = c[sa[i - 1]] + 1;
    }

    int k = 0;
    while ((1 << k) < n)
    {
        for (int i = 0; i < n; i++)
            sa[i] = (sa[i] - (1 << k) + n) % n;
        countingSort(sa, c);
        vi c_new(n);
        c_new[sa[0]] = 0;
        for (int i = 1; i < n; i++)
        {
            ii curr = {c[sa[i]], c[(sa[i] + (1 << k)) % n]};
            ii prev = {c[sa[i - 1]], c[(sa[i - 1] + (1 << k)) % n]};
            if (curr == prev)
                c_new[sa[i]] = c_new[sa[i - 1]];
            else
                c_new[sa[i]] = c_new[sa[i - 1]] + 1;
        }
        c = c_new;
        k++;
    }

    k = 0;
    vector<int> lcp(n, 0);
    for (int i = 0; i < n - 1; i++)
    {
        int pi = c[i];
        int bef = sa[pi - 1];
        while (s[i + k] == s[bef + k])
            k++;
        lcp[pi] = k;
        k = max(0, k - 1);
    }
    int cmax = 0, pos = -1;
    for (int i = 1; i < n; i++)
    {
        if (lcp[i] > cmax)
        {
            cmax = lcp[i];
            pos = sa[i];
        }
    }
    if (cmax == 0)
        cout << "-1\n";
    else
        cout << s.substr(pos, cmax);
}

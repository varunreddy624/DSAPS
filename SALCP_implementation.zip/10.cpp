#pragma GCC optimize("O2")
#include <bits/stdc++.h>
#define ll long long
#define For(i, a, b) for (ll i = a; i <= b; i++)
#define Fd(i, a, b) for (ll i = a; i >= b; i--)
#define task "A"
#define ii pair<ll, ll>
#define F first
#define S second
#define pb push_back
#define eb emplace_back
#define all(x) x.begin(), x.end()
#define SZ(x) (ll) x.size()
#define DB(x) cerr << #x << " = " << x << '\n'
#define DB2(a, i, j) cerr << #a << "[" << i << "," << j << "] = " << a[i][j] << '\n'
#define DB1(a, i) cerr << #a << "[" << i << "] = " << a[i] << '\n'
#define DB3(a, i, j, k) cerr << #a << "[" << i << "," << j << "," << k << "] = " << a[i][j][k] << '\n'
#define vi vector<ll>
#define max(...) max({__VA_ARGS__})
#define min(...) min({__VA_ARGS__})
#define bit(mask) bitset<10>(mask)

const ll INF = 1e18;
const ll mod = 1e9 + 7;
const ll N = 2e5 + 1;
typedef ll Array[N];

using namespace std;

string st;
ll n, G;
Array sa, ra, rb;

bool cmp(const ll &x, const ll &y)
{
    if (ra[x] != ra[y])
        return ra[x] < ra[y];
    return ra[x + G] < ra[y + G];
}

int main()
{
    if (fopen(task ".inp", "r"))
        freopen(task ".inp", "r", stdin);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> st;
    n = SZ(st);
    st = '#' + st;
    For(i, 1, n)
    {
        sa[i] = i;
        ra[i] = st[i];
    }
    for (G = 1; G <= n; G <<= 1)
    {
        sort(sa + 1, sa + n + 1, cmp);
        For(i, 1, n) rb[sa[i]] = rb[sa[i - 1]] + cmp(sa[i - 1], sa[i]);
        For(i, 1, n) ra[i] = rb[i];
        if (ra[sa[n]] == n)
            break;
    }
    vi pre(n + 1, 0), lcp(n + 1, 0), plcp(n + 1, 0);
    pre[sa[1]] = -1;
    For(i, 2, n) pre[sa[i]] = sa[i - 1];

    ll k = 0;
    For(i, 1, n)
    {
        if (pre[i] == -1)
        {
            plcp[i] = 0;
            continue;
        }
        while (st[i + k] == st[pre[i] + k])
            k++;
        plcp[i] = k;
        k = max(k - 1, 0ll);
    }
    For(i, 1, n) lcp[i] = plcp[sa[i]];
    ll Max = *max_element(all(lcp));
    if (Max == 0)
        return cout << -1, 0;
    For(i, 1, n) if (lcp[i] == Max)
    {
        For(j, sa[i], sa[i] + Max - 1) cout << st[j];
        break;
    }
}
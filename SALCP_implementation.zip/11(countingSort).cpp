#include <bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;

#ifdef local
#define debug(x) (cerr << #x << " = " << (x) << '\n')
#define BUILD_COMPLETE cerr << "Build Complete\n";
#else
#define debug(x) ((void)0)
#define BUILD_COMPLETE ((void)0);
#endif // local

#define int long long
typedef int64_t ll;
typedef long double ld;

#define pb emplace_back
#define mp make_pair
#define mt make_tuple
#define pii pair<int, int>
#define F(n) Fi(i, n)
#define Fi(i, n) Fl(i, 0, n)
#define Fl(i, l, n) for (int i = l; i < n; i++)
#define all(v) begin(v), end(v)
#define siz(v) (ll(v.size()))
#define get_pos(v, x) (lower_bound(all(v), x) - begin(v))
#define sort_uni(v) sort(begin(v), end(v)), v.erase(unique(begin(v), end(v)), end(v))
#define mem(v, x) memset(v, x, sizeof v)
#define ff first
#define ss second
#define mid ((l + r) >> 1)
struct custom_hash
{
    static uint64_t splitmix64(uint64_t x)
    {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const
    {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

template <typename T>
using max_heap = __gnu_pbds::priority_queue<T, less<T>>;
template <typename T>
using min_heap = __gnu_pbds::priority_queue<T, greater<T>>;
template <typename T>
using rbt = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

void R() { return; }
template <typename I, typename... T>
void R(I &i, T &...t)
{
    cin >> i;
    R(t...);
}

void counting_sort(int *rank, int *pos, int n)
{
    int cnt[n] = {};
    F(n)
    cnt[rank[pos[i]]]++;
    Fl(i, 1, n) cnt[i] += cnt[i - 1];
    int ans[n];
    for (int i = n - 1; i >= 0; i--)
        ans[--cnt[rank[pos[i]]]] = pos[i];
    F(n)
    pos[i] = ans[i];
}

void suffixArray(string s, int *pos, int *lcp)
{
    s += "%";
    int n = s.size();
    iota(pos, pos + n, 0);
    sort(pos, pos + n, [&](int a, int b)
         { return s[a] < s[b]; });

    int rank[n];
    int new_rank[n];
    rank[pos[0]] = 0;
    Fl(i, 1, n) rank[pos[i]] = rank[pos[i - 1]] + (s[pos[i]] != s[pos[i - 1]]);
    for (int k = 0; (1 << k) <= n; k++)
    {
        F(n)
        pos[i] = (pos[i] - (1 << k) % n + n) % n;
        counting_sort(rank, pos, n);
        new_rank[pos[0]] = 0;
        Fl(i, 1, n)
        {
            pii prev = {rank[pos[i - 1]], rank[(pos[i - 1] + (1 << k)) % n]};
            pii now = {rank[pos[i]], rank[(pos[i] + (1 << k)) % n]};
            new_rank[pos[i]] = new_rank[pos[i - 1]] + (prev != now);
        }
        F(n)
        rank[i] = new_rank[i];
    }

    int k = 0;
    F(n)
    {
        int pi = rank[i];
        int j = pos[pi - 1];
        while (i + k < n && j + k < n && s[i + k] == s[j + k])
            k++;
        lcp[pi] = k;
        k = max(0ll, k - 1);
    }
}

signed main()
{
    BUILD_COMPLETE
    cin.tie(0);
    std::ios_base::sync_with_stdio(false);

    string s;
    R(s);
    int n = s.size();

    int pos[n + 1];
    int lcp[n + 1];
    suffixArray(s, pos, lcp);
    //F(n+1) printf("%lld ", lcp[i]);

    int mx = 0;
    int x = 0;
    Fl(i, 1, n + 1)
    {
        if (lcp[i] > mx)
        {
            mx = lcp[i];
            x = i;
        }
    }
    if (mx == 0)
        printf("-1");
    else
        printf("%s", s.substr(pos[x], mx).c_str());
    return 0;
}
#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;

vector<int> suffix_array(string &str, char b = 'a', char e = 'z')
{
    char s = b - 1;
    str += s;

    size_t N = str.size(), alph_size = e - b + 1;
    vector<int> P(N), C(N), cnt(max(alph_size + 1, N), 0);
    int classes = 0;

    for (char c : str)
    {
        ++cnt[c - s];
    }
    for (size_t i = 1; i <= alph_size; ++i)
    {
        cnt[i] += cnt[i - 1];
    }
    for (size_t i = 0; i < N; ++i)
    {
        C[i] = str[i] - s;
        classes = max(classes, C[i]);
        P[--cnt[C[i]]] = i;
    }

    vector<int> P2(N), C2(N);
    for (size_t last_len = 1; last_len < N; last_len <<= 1)
    {
        for (size_t i = 0; i < N; ++i)
        {
            P2[i] = P[i] - last_len;
            if (P2[i] < 0)
            {
                P2[i] += N;
            }
        }

        fill(cnt.begin(), cnt.begin() + classes + 1, 0);
        for (size_t i = 0; i < N; ++i)
        {
            ++cnt[C[P2[i]]];
        }
        for (int i = 1; i <= classes; ++i)
        {
            cnt[i] += cnt[i - 1];
        }
        for (int i = N - 1; i >= 0; --i)
        {
            P[--cnt[C[P2[i]]]] = P2[i];
        }

        classes = 0;
        C2[P[0]] = 0;
        for (size_t i = 1; i < N; ++i)
        {
            pair curr = {C[P[i]], C[(P[i] + last_len) % N]};
            pair prev = {C[P[i - 1]], C[(P[i - 1] + last_len) % N]};

            C2[P[i]] = (classes += (curr != prev));
        }

        C.swap(C2);
    }

    str.pop_back();
    P.erase(P.begin());

    return P;
}

vector<int> lcp_array(string &str, const vector<int> &sa)
{
    int N = str.size();
    vector<int> rank(N);
    for (int i = 0; i < N; ++i)
    {
        rank[sa[i]] = i;
    }

    int k = 0;
    vector<int> lcp(N);
    for (int i = 0; i < N; ++i)
    {
        if (rank[i] == N - 1)
        {
            lcp[N - 1] = 0;
            k = 0;
            continue;
        }

        int j = sa[rank[i] + 1];
        while (i + k < N && j + k < N && str[i + k] == str[j + k])
        {
            ++k;
        }

        lcp[rank[i]] = k;

        if (k > 0)
        {
            --k;
        }
    }

    return lcp;
}

int main()
{
    string str;
    cin >> str;
    // Input Done

    // obsv: every substr in a str is a prefix of some suffix. If we
    // sorted these suffices (i.e. suffix array) and found all LCP's,
    // then each lcp[i] represents a substr of length i that occurs
    // at least twice. Thus, our answer is just the longest common
    // prefix between any two adjacent substr's in the suffix array.
    vector<int> sa = suffix_array(str), lcp = lcp_array(str, sa);

    int max_lcp = 0, best_ind = -1;
    for (size_t i = 0; i < lcp.size(); ++i)
    {
        if (lcp[i] > max_lcp)
        {
            max_lcp = lcp[i];
            best_ind = sa[i];
        }
    }

    if (best_ind == -1)
    { // there is no repeating substr
        cout << -1 << '\n';
    }
    else
    {
        cout << str.substr(best_ind, max_lcp) << '\n';
    }

    return 0;
}
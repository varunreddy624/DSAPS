#include <bits/stdc++.h>

using namespace std;

vector<int> build_sa(string &s)
{
    int n = (int)s.size();
    vector<int> sa(n), pos(n), tmp(n), cnt(n);
    iota(sa.begin(), sa.end(), 0);
    sort(sa.begin(), sa.end(), [&](int i, int j)
         { return s[i] < s[j]; });
    for (int i = 0; i < n; i++)
    {
        pos[i] = lower_bound(sa.begin(), sa.end(), s[i], [&](int d, char c)
                             { return s[d] < c; }) -
                 sa.begin();
    }
    for (int gap = 1; gap < n; gap *= 2)
    {
        int r = gap;
        for (int i = 0; i < n; i++)
        {
            if (sa[i] >= gap)
            {
                tmp[r++] = sa[i] - gap;
            }
        }
        iota(tmp.begin(), tmp.begin() + gap, n - gap);
        fill(cnt.begin(), cnt.end(), 0);
        for (int i = 0; i < n; i++)
        {
            if (pos[i] < n - 1)
            {
                cnt[pos[i] + 1]++;
            }
        }
        partial_sum(cnt.begin(), cnt.end(), cnt.begin());
        for (int i = 0; i < n; i++)
        {
            sa[cnt[pos[tmp[i]]]++] = tmp[i];
        }
        auto cmp = [&](int i, int j)
        {
            if (pos[i] != pos[j])
            {
                return pos[i] < pos[j];
            }
            int ri = i + gap < n ? pos[i + gap] : -1;
            int rj = j + gap < n ? pos[j + gap] : -1;
            return ri < rj;
        };
        tmp[sa[0]] = 0;
        for (int i = 1; i < n; i++)
        {
            tmp[sa[i]] = tmp[sa[i - 1]] + cmp(sa[i - 1], sa[i]);
        }
        pos.swap(tmp);
    }
    return sa;
}

vector<int> build_lcp(string &s, vector<int> &sa)
{
    int n = (int)s.size();
    vector<int> pos(n);
    for (int i = 0; i < n; i++)
    {
        pos[sa[i]] = i;
    }
    vector<int> lcp(n - 1);
    int r = 0;
    for (int i = 0; i < n; i++)
    {
        if (r > 0)
        {
            r--;
        }
        if (pos[i] == 0)
        {
            continue;
        }
        for (int j = sa[pos[i] - 1]; j + r < n && i + r < n; r++)
        {
            if (s[j + r] != s[i + r])
            {
                break;
            }
        }
        lcp[pos[i] - 1] = r;
    }
    return lcp;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    string s;
    cin >> s;
    if ((int)s.size() == 1)
    {
        cout << -1;
        return 0;
    }
    vector<int> sa = build_sa(s);
    vector<int> lcp = build_lcp(s, sa);
    int pos = max_element(lcp.begin(), lcp.end()) - lcp.begin();
    if (lcp[pos] == 0)
    {
        cout << -1;
        return 0;
    }
    cout << s.substr(sa[pos], lcp[pos]);
}
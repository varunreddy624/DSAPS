//gyrating cat enthusiast
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <utility>
#include <cassert>
#include <algorithm>
#include <vector>
#include <random>
#include <chrono>
#include <queue>
#include <set>

#define ll long long
#define lb long double
#define pii pair<int, int>
#define pb push_back
#define mp make_pair
#define ins insert
#define cont continue
#define siz(vec) ((int)(vec.size()))

#define LC(n) (((n) << 1) + 1)
#define RC(n) (((n) << 1) + 2)
#define init(arr, val) memset(arr, val, sizeof(arr))
#define bckt(arr, val, sz) memset(arr, val, sizeof(arr[0]) * (sz + 5))
#define uid(a, b) uniform_int_distribution<int>(a, b)(rng)
#define tern(a, b, c) ((a) ? (b) : (c))
#define feq(a, b) (fabs(a - b) < eps)
#define abs(x) tern((x) > 0, x, -(x))

#define moo printf
#define oom scanf
#define mool puts("")
#define orz assert
#define fll fflush(stdout)

const lb eps = 1e-9;
const ll mod = 1e9 + 7, ll_max = (ll)1e18;
const int MX = 2e5 + 10, max_v = 2e5 + 10, LOGN = 30, int_max = 0x3f3f3f3f;

using namespace std;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

char str[max_v];
int sa[max_v], rk[max_v], buckets[max_v], lcp[max_v]; //using buckets for readability
int tmp[max_v], pos[max_v], st[max_v * 2][LOGN], n;

void print_arr(int n, int *arr)
{
    for (int i = 1; i <= n; i++)
        printf("%d ", arr[i]);
    puts("");
}

void comp_SA()
{
    int mx = 260;
    for (int i = 1; i <= n; i++)
    {
        sa[i] = i;
        rk[i] = str[i];
    }

    for (int i = 1; i >> 1 < n; i <<= 1)
    {
        int k = i >> 1, p = k;
        for (int j = 1; j <= k; j++)
            buckets[j] = n - (j - 1);
        for (int j = 1; j <= n; j++)
            if (sa[j] > k)
                buckets[++p] = sa[j] - k;
        memset(pos, 0, sizeof(pos));
        for (int j = 1; j <= n; j++)
            pos[rk[j]]++;
        for (int j = 1; j <= mx; j++)
            pos[j] += pos[j - 1];
        for (int j = n; j; j--)
            sa[pos[rk[buckets[j]]]--] = buckets[j];
        for (int j = 1; j <= n; j++)
            tmp[sa[j]] = tmp[sa[j - 1]] + (rk[sa[j]] != rk[sa[j - 1]] || rk[sa[j] + k] != rk[sa[j - 1] + k]);
        for (int j = 1; j <= n; j++)
            rk[j] = tmp[j];
        mx = rk[sa[n]];
        if (mx == n)
            break; //optimization to help run faster on 'sparser strings'
    }
    //this passed luogu sample problem. so it's all good
}

void make_lcp()
{
    for (int i = 1; i <= n; i++)
    {
        lcp[rk[i]] = max(0, lcp[rk[i - 1]] - 1);
        for (; str[i + lcp[rk[i]]] == str[sa[rk[i] - 1] + lcp[rk[i]]]; lcp[rk[i]]++)
            ; //clean and concise from teachers code
    }         //linear complexity. proving this was a massive pain
}

int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin >> (str + 1);
    n = strlen(str + 1);
    comp_SA();
    make_lcp();
    int ans = 0, ind;
    for (int i = 1; i <= n; i++)
    {
        if (lcp[i] > ans)
        {
            ans = lcp[i];
            ind = sa[i];
        }
    }
    if (ans)
    {
        for (int i = ind; i < ind + ans; i++)
        {
            cout << str[i];
        }
        cout << "\n";
    }
    else
    {
        cout << "-1\n";
    }
    return 0;
}

#include <bits/stdc++.h>
#define SZ(X) ((int)(X).size())
#define MP make_pair
#define PB emplace_back
using namespace std;
const int MAXLEN = 1 << 20;

char s[MAXLEN];
int SA[MAXLEN], cnt[MAXLEN], ary1[MAXLEN], ary2[MAXLEN];
int *Rank, *Height;

inline bool cmp(int *r, int a, int b, int l)
{
    return r[a] == r[b] && r[a + l] == r[b + l];
}

void make_suffix_array(int MSIZE, int len)
{
    int p, *x, *y, *tmp, i, j, k;
    x = ary1;
    y = ary2;
    memset(cnt, 0, sizeof(int) * MSIZE);
    for (i = 0; i < len; i++)
        cnt[x[i] = s[i]]++;
    for (i = 1; i < MSIZE; i++)
        cnt[i] += cnt[i - 1];
    for (i = len - 1; i >= 0; i--)
        SA[--cnt[x[i]]] = i;
    for (j = p = 1; p < len; j <<= 1, MSIZE = p)
    {
        for (p = 0, i = len - j; i < len; i++)
            y[p++] = i;
        for (i = 0; i < len; i++)
        {
            if (SA[i] >= j)
                y[p++] = SA[i] - j;
        }
        memset(cnt, 0, sizeof(int) * MSIZE);
        for (i = 0; i < len; i++)
            cnt[x[y[i]]]++;
        for (i = 1; i < MSIZE; i++)
            cnt[i] += cnt[i - 1];
        for (i = len - 1; i >= 0; i--)
            SA[--cnt[x[y[i]]]] = y[i];
        tmp = x;
        x = y;
        y = tmp;
        x[SA[0]] = 0;
        for (i = p = 1; i < len; i++)
        {
            x[SA[i]] = cmp(y, SA[i - 1], SA[i], j) ? p - 1 : p++;
        }
    }
    Rank = x;
    Height = y;
    for (i = k = 0; i < len - 1; i++)
    {
        if (k > 0)
            k--;
        j = SA[Rank[i] - 1];
        while (s[i + k] == s[j + k])
            k++;
        Height[Rank[i]] = k;
    }
    *Height = 0;
}
/* 字串的最後一個元素必須是 0。
 * SA[k] 儲存第 k 小的 suffix 的開頭 index
 * Rank[k] 是 SA 的反函數，儲存 index 為 k 的 suffix 排序後的位置
 * Height[k] 是第 k 小的 suffix 和第 k-1 小的 suffix 的最長共同前綴長度
 */
void solve()
{
    scanf("%s", s);
    int len = strlen(s);
    int ll = 0, rr = len;
    len++; // this line is important
    make_suffix_array(128, len);
    auto it = max_element(Height + 2, Height + len);
    if (*it == 0)
    {
        puts("-1");
    }
    else
    {
        s[SA[it - Height] + *it] = 0;
        puts(s + SA[it - Height]);
    }
}
int main()
{
    solve();
    return 0;
}
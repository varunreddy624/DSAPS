#include <bits/stdc++.h>

using namespace std;
//@formatter:off
#ifdef lol
const bool dbg = true;
#else
const bool dbg = false;
#endif
#define dout \
    if (dbg) \
    cout
#define fin(i, s, n) for (auto i = s; i < n; ++i)
#define fine(i, s, n) for (auto i = s; i <= n; ++i)
//#define int int64_t
#define x first
#define y second
#define pb push_back
#define eb emplace_back
#define def(x) \
    int x;     \
    cin >> x
#define cases \
    def(t);   \
    while (t--)
#define cases1 \
    int t = 1; \
    while (t--)
#define all(x) (x).begin(), (x).end()
#define chkmax(a, b) a = max(a, b)
#define chkmin(a, b) a = min(a, b)
using ii = pair<int, int>;
using vi = vector<int>;
using vvi = vector<vector<int>>;
using vii = vector<ii>;
using vvii = vector<vector<ii>>;
using ld = long double;
//using bigint = __int128;
#define tct template <class T>
#define tcab template <class A, class B>
tcab ostream &operator<<(ostream &os, pair<A, B> p)
{
    return os << '{' << p.x << ',' << p.y << '}';
}
tct ostream &operator<<(ostream &os, vector<T> v)
{
    os << '[';
    if (!v.empty())
    {
        os << v[0];
        fin(i, 1, v.size()) os << ',' << v[i];
    }
    return os << ']';
}
tcab istream &operator>>(istream &is, pair<A, B> &p) { return is >> p.x >> p.y; }
tct istream &operator>>(istream &is, vector<T> &v)
{
    for (auto &x : v)
        is >> x;
    return is;
}
#define popcnt(x) __builtin_popcount(x)
//#define sz(x) int(x.size())
int rnd() { return rand() ^ (rand() << 15); }
int gcd(int a, int b) { return b ? gcd(b, a % b) : a; }
//@formatter:on
const int maxn = 1e6 + 5;
//linear time suffix array building
//as shown in Simple Linear Work Suffix Array Construction,
//found at http://www.cs.cmu.edu/~guyb/realworld/papersS04/KaSa03.pdf
namespace LinearSuffixArray
{
    inline bool leq(int a1, int a2, int b1, int b2) { return a1 < b1 || (a1 == b1 && a2 <= b2); }

    inline bool leq(int a1, int a2, int a3, int b1, int b2, int b3)
    {
        return a1 < b1 || (a1 == b1 && (a2 < b2 || (a2 == b2 && a3 <= b3)));
    }

    int c[maxn];

    static void radixPass(int *a, int *b, int *r, int n, int K)
    {
        fine(i, 0, K) c[i] = 0;
        fin(i, 0, n) c[r[a[i]] + 1]++;
        fine(i, 1, K) c[i] += c[i - 1];
        fin(i, 0, n) b[c[r[a[i]]]++] = a[i];
    }

    void suffixArray(int *s, int *SA, int n, int K)
    {
        int n0 = (n + 2) / 3, n1 = (n + 1) / 3, n2 = n / 3, n02 = n0 + n2;
        int *s12 = new int[n02 + 3], *s0 = new int[n0], *SA0 = new int[n0], *SA12 = new int[n02 + 3];
        s12[n02] = s12[n02 + 1] = s12[n02 + 2] = SA12[n02] = SA12[n02 + 1] = SA12[n02 + 2] = 0;
        for (int i = 0, j = 0; i < n + (n0 - n1); i++)
            if (i % 3 != 0)
                s12[j++] = i;
        fine(j, 0, 2) radixPass(j & 1 ? SA12 : s12, j & 1 ? s12 : SA12, s + 2 - j, n02, K);
        int name = 0, c0 = -1, c1 = -1, c2 = -1;
        for (int i = 0; i < n02; i++)
        {
            if (s[SA12[i]] != c0 || s[SA12[i] + 1] != c1 || s[SA12[i] + 2] != c2)
                ++name, c0 = s[SA12[i]], c1 = s[SA12[i] + 1], c2 = s[SA12[i] + 2];
            s12[SA12[i] / 3 + (SA12[i] % 3 != 1 ? n0 : 0)] = name;
        }
        if (name < n02)
        {
            suffixArray(s12, SA12, n02, name);
            fin(i, 0, n02) s12[SA12[i]] = i + 1;
        }
        else
            fin(i, 0, n02) SA12[s12[i] - 1] = i;
        for (int i = 0, j = 0; i < n02; i++)
            if (SA12[i] < n0)
                s0[j++] = 3 * SA12[i];
        radixPass(s0, SA0, s, n0, K);
        for (int p = 0, t = n0 - n1, k = 0; k < n; k++)
        {
#define GetI() (SA12[t] < n0 ? SA12[t] * 3 + 1 : (SA12[t] - n0) * 3 + 2)
            int i = GetI();
            int j = SA0[p];
            if (SA12[t] < n0 ? leq(s[i], s12[SA12[t] + n0], s[j], s12[j / 3]) : leq(s[i], s[i + 1], s12[SA12[t] - n0 + 1], s[j], s[j + 1], s12[j / 3 + n0]))
            {
                SA[k] = i;
                t++;
                if (t == n02)
                    for (k++; p < n0; p++, k++)
                        SA[k] = SA0[p];
            }
            else
            {
                SA[k] = j;
                p++;
                if (p == n0)
                    for (k++; t < n02; t++, k++)
                        SA[k] = GetI();
            }
        }
    }

    void calc_sa(const string &s, vi &ans)
    {
        if (s.empty())
            return;
        int n = s.size();
        if (n != int(ans.size()))
            ans.resize(n);
        if (n <= 3)
        {
            iota(all(ans), 0);
            sort(all(ans), [s](int i, int j)
                 { return s.substr(i) < s.substr(j); });
        }
        else
        {
            int *_s = new int[n + 3], *_sa = new int[n];
            fin(i, 0, n) _s[i] = s[i];
            _s[n] = _s[n + 1] = _s[n + 2] = 0;
            suffixArray(_s, _sa, n, *max_element(all(s)));
            int nt = n, j = 0;
            fin(i, 0, nt) if (_sa[i] < n) ans[j++] = _sa[i];
        }
    }

    void calc_cyclic_sa(string &s, vi &ans)
    {
        if (s.empty())
            return;
        int n = s.size();
        s = s + s;
        vi cans;
        calc_sa(s, cans);
        s.resize(n);
        ans.resize(n);
        int nt = n << 1, j = 0;
        fin(i, 0, nt) if (cans[i] < n) ans[j++] = cans[i];
    }

    void calc_lcp(const string &s, const vi &sa, vi &lcp)
    {
        int n = s.size(), k = 0;
        vi rank(n, 0);
        fin(i, 0, n) rank[sa[i]] = i;
        for (int i = 0; i < n; i++)
        {
            if (rank[i] == n - 1)
            {
                k = 0;
                continue;
            }
            for (int j = sa[rank[i] + 1]; i + k < n && j + k < n && s[i + k] == s[j + k]; ++k)
                ;
            lcp[rank[i]] = k;
            if (k)
                k--;
        }
    }
}

int32_t main()
{
    cin.tie(0)->sync_with_stdio(0);
    string S;
    cin >> S;
    int n = S.size();
    vi sa;
    LinearSuffixArray::calc_sa(S, sa);
    vi lcp(n - 1);
    LinearSuffixArray::calc_lcp(S, sa, lcp);
    int i = max_element(all(lcp)) - lcp.begin();
    if (lcp[i] == 0)
        cout << -1;
    else
        cout << S.substr(sa[i], lcp[i]);
    cout << endl;
    return 0;
}
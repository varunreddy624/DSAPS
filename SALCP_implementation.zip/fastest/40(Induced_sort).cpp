#include "bits/extc++.h"

using namespace std;

template <class T>
using mpq = priority_queue<T, vector<T>, greater<>>;

template <class T, class U = less<T>>
using rt = __gnu_pbds::tree<T, __gnu_pbds::null_type, U, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update>;

template <class T>
void dbgh(const T &t)
{
    cerr << t << endl;
}

template <class T, class... U>
void dbgh(const T &t, const U &...u)
{
    cerr << t << " | ";
    dbgh(u...);
}

#ifdef DEBUG
#define dbg(...)                                           \
    cerr << "L" << __LINE__ << " [" << #__VA_ARGS__ << "]" \
         << ": ";                                          \
    dbgh(__VA_ARGS__)
#else
#define cerr   \
    if (false) \
    cerr
#define dbg(...) 1412
#endif

//imagine a language where int = long
#define long int64_t

//typing too hard
#define endl "\n"

#define sz(x) static_cast<int>((x).size())

#define inline inline __attribute__((always_inline))

// based on https://judge.yosupo.jp/submission/52300
template <bool emptySuffix = false, bool genLcp = false, bool genSuffixes = false>
struct SuffixArray
{
    int n;
    string s;
    vector<int> arr, lcp;
    vector<string_view> suffixes;

    SuffixArray(const string &s) : SuffixArray(s, conv) {}

    template <typename Conv>
    SuffixArray(const string &s, const Conv &conv) : n(sz(s)), s(s), arr{}, lcp{}, suffixes{}
    {
        vector<int> tmp(n + 1);
        for (int i = 0; i < n; i++)
        {
            tmp[i] = conv(s[i]) + 1;
        }
        arr = SA_IS(tmp, *max_element(begin(tmp), end(tmp)) + 2);
        if (!emptySuffix)
        {
            arr.erase(arr.begin());
        }
        if (genLcp)
        {
            genLcpArray();
        }
        if (genSuffixes)
        {
            genSuffixArray();
        }
    }

    static int conv(char c)
    {
        if (islower(c))
        {
            return c - 'a';
        }
        else if (isupper(c))
        {
            return 26 + c - 'A';
        }
        else if (isdigit(c))
        {
            return 52 + c - '0';
        }
        return 62 + c;
    }

    static void induced_sort(const vector<int> &vec, int val_range, vector<int> &SA, const vector<bool> &sl,
                             const vector<int> &lms_idx)
    {
        vector<int> l(val_range, 0), r(val_range, 0);
        for (int c : vec)
        {
            if (c + 1 < val_range)
                ++l[c + 1];
            ++r[c];
        }
        partial_sum(l.begin(), l.end(), l.begin());
        partial_sum(r.begin(), r.end(), r.begin());
        fill(SA.begin(), SA.end(), -1);
        for (int i = (int)lms_idx.size() - 1; i >= 0; --i)
            SA[--r[vec[lms_idx[i]]]] = lms_idx[i];
        for (int i : SA)
            if (i >= 1 && sl[i - 1])
                SA[l[vec[i - 1]]++] = i - 1;
        fill(r.begin(), r.end(), 0);
        for (int c : vec)
            ++r[c];
        partial_sum(r.begin(), r.end(), r.begin());
        for (int k = (int)SA.size() - 1, i = SA[k]; k >= 1; --k, i = SA[k])
            if (i >= 1 && !sl[i - 1])
            {
                SA[--r[vec[i - 1]]] = i - 1;
            }
    }

    static vector<int> SA_IS(const vector<int> &vec, int val_range)
    {
        const int n = vec.size();
        vector<int> SA(n), lms_idx;
        vector<bool> sl(n);
        sl[n - 1] = false;
        for (int i = n - 2; i >= 0; --i)
        {
            sl[i] = (vec[i] > vec[i + 1] || (vec[i] == vec[i + 1] && sl[i + 1]));
            if (sl[i] && !sl[i + 1])
                lms_idx.push_back(i + 1);
        }
        reverse(lms_idx.begin(), lms_idx.end());
        induced_sort(vec, val_range, SA, sl, lms_idx);
        vector<int> new_lms_idx(lms_idx.size()), lms_vec(lms_idx.size());
        for (int i = 0, k = 0; i < n; ++i)
            if (!sl[SA[i]] && SA[i] >= 1 && sl[SA[i] - 1])
            {
                new_lms_idx[k++] = SA[i];
            }
        int cur = 0;
        SA[n - 1] = cur;
        for (size_t k = 1; k < new_lms_idx.size(); ++k)
        {
            int i = new_lms_idx[k - 1], j = new_lms_idx[k];
            if (vec[i] != vec[j])
            {
                SA[j] = ++cur;
                continue;
            }
            bool flag = false;
            for (int a = i + 1, b = j + 1;; ++a, ++b)
            {
                if (vec[a] != vec[b])
                {
                    flag = true;
                    break;
                }
                if ((!sl[a] && sl[a - 1]) || (!sl[b] && sl[b - 1]))
                {
                    flag = !((!sl[a] && sl[a - 1]) && (!sl[b] && sl[b - 1]));
                    break;
                }
            }
            SA[j] = (flag ? ++cur : cur);
        }
        for (size_t i = 0; i < lms_idx.size(); ++i)
            lms_vec[i] = SA[lms_idx[i]];
        if (cur + 1 < (int)lms_idx.size())
        {
            auto lms_SA = SA_IS(lms_vec, cur + 1);
            for (size_t i = 0; i < lms_idx.size(); ++i)
            {
                new_lms_idx[i] = lms_idx[lms_SA[i]];
            }
        }
        induced_sort(vec, val_range, SA, sl, new_lms_idx);
        return SA;
    }

    // Author: https://codeforces.com/blog/entry/12796?#comment-175287
    // Uses kasai's algorithm linear in time and space
    void genLcpArray()
    {
        int n = sz(arr), k = 0;
        lcp.resize(n);
        vector<int> rank(n + 1);
        for (int i = 0; i < n; i++)
            rank[arr[i]] = i;
        for (int i = 0; i < n; i++, k ? k-- : 0)
        {
            if (rank[i] == n - 1)
            {
                k = 0;
                continue;
            }
            int j = arr[rank[i] + 1];
            while (i + k < n && j + k < n && s[i + k] == s[j + k])
                k++;
            lcp[rank[i]] = k;
        }
        lcp[n - 1] = 0;
    }

    void genSuffixArray()
    {
        suffixes.resize(sz(arr));
        string_view x(s);
        for (int i = 0; i < sz(arr); i++)
        {
            suffixes[i] = x.substr(arr[i]);
        }
    }
};

void solve()
{
    string s;
    cin >> s;
    SuffixArray<false, true> sa(s);
    vector<int> arr = sa.lcp;
    pair<int, int> ans{};
    for (int i = 0; i < sz(s) - 1; i++)
    {
        ans = max(ans, pair<int, int>{sa.lcp[i], sa.arr[i]});
    }
    if (ans.first)
    {
        cout << s.substr(ans.second, ans.first) << endl;
    }
    else
    {
        cout << -1 << endl;
    }
}

int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(ios::failbit);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif
    int t = 1;
    //	cin >> t;
    for (int _ = 1; _ <= t; _++)
    {
        dbg(_);
        //		cout << "Case #" << _ << ": ";
        solve();
    }
}
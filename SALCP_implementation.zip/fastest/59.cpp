/**
*   author:  akifpathan
*   created: Saturday 13.02.2021 12:02:13 PM
**/

/*
#pragma GCC optimize("Ofast")
//#pragma GCC optimize ("unroll-loops")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
*/

#ifdef akifpathan
#include "debug.h"
#else
#include <bits/stdc++.h>
using namespace std;
#define debug(x...)
#endif

/*
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template<class T> 
using ordered_set= tree<T, null_type, 
		less<T>, 
		rb_tree_tag, tree_order_statistics_node_update> ;
template<class T> 		
using ordered_mset= tree<T, null_type, 
		less_equal<T>, 
		rb_tree_tag, tree_order_statistics_node_update> ;
		
*/

/*
 
PBDS
-------------------------------------------------
			0 based indexing
-------------------------------------------------			 
1) insert(value)
2) erase(value)
3) order_of_key(value) // Number of items strictly smaller than value
4) *find_by_order(k) : K-th element in a set (counting from zero)
 
*/

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

//mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

/*
 * nlogn approach for suffix array
 * sa[i] denotes the position of i'th suffix in lexicographical order
 * sa[0]=n
 * lcp[i] denotes longest common prefix(sa[i-1],sa[i])
 * if we want to find lcp(i,j) then we need
 * to build a sparse table
 * lcp(i,j)=min(sparse_table.query(i+1,j))
*/

struct suffix_array
{
    vector<int> sa, lcp;
    suffix_array(string &s, int lim = 256)
    { // or basic_string<int>
#define rep(i, a, b) for (int i = a; i < b; i++)
        int n = s.size() + 1, k = 0, a, b;
        vector<int> x(s.begin(), s.end() + 1), y(n), ws(max(n, lim)), rank(n);
        sa = lcp = y, iota(sa.begin(), sa.end(), 0);
        for (int j = 0, p = 0; p < n; j = max(1, j * 2), lim = p)
        {
            p = j, iota(y.begin(), y.end(), n - j);
            rep(i, 0, n) if (sa[i] >= j) y[p++] = sa[i] - j;
            fill(ws.begin(), ws.end(), 0);
            rep(i, 0, n) ws[x[i]]++;
            rep(i, 1, lim) ws[i] += ws[i - 1];
            for (int i = n; i--;)
                sa[--ws[x[y[i]]]] = y[i];
            swap(x, y), p = 1, x[sa[0]] = 0;
            rep(i, 1, n) a = sa[i - 1], b = sa[i], x[b] = (y[a] == y[b] && y[a + j] == y[b + j]) ? p - 1 : p++;
        }
        rep(i, 1, n) rank[sa[i]] = i;
        for (int i = 0, j; i < n - 1; lcp[rank[i++]] = k)
            for (k &&k--, j = sa[rank[i] - 1];
                 s[i + k] == s[j + k]; k++)
                ;
#undef rep
    }
};

void solve()
{
    string x;
    cin >> x;

    suffix_array sa(x);

    int maxi = 0;
    int pos = 0;

    for (int i = 1; i < sa.lcp.size(); i++)
    {
        if (sa.lcp[i] > maxi)
        {
            maxi = sa.lcp[i];
            pos = sa.sa[i];
        }
    }

    if (maxi == 0)
        cout << -1;
    else
        cout << x.substr(pos, maxi);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int testcase = 1;
    //cin>>testcase;

    for (int i = 1; i <= testcase; i++)
    {
        //cout<<"Case "<<i<<": ";
        solve();
    }

#ifdef akifpathan
    cerr << "\nTime elapsed: " << 1000.0 * clock() / CLOCKS_PER_SEC << " ms\n";
#endif

    return 0;
}
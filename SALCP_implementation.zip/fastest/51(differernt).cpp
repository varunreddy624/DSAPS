#include <bits/stdc++.h>
using namespace std;

int main()
{

#ifndef ONLINE_JUDGE
    freopen("SuhaibSawalha1", "r", stdin);
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    string s;
    cin >> s;
    int n = s.size();
    vector<int> sa(n + 1), start(n + 1), rank(n + 1), newrank(n + 1), newsa(max(128, n + 1)), lcp(n + 1);
#define head newsa
#define next newrank
    for (int i = 0; i < 128; ++i)
    {
        head[i] = -1;
    }
    for (int i = 0; i <= n; ++i)
    {
        sa[i] = i;
        next[i] = head[s[i]];
        head[s[i]] = i;
    }
    int p = 0, b = -1;
    for (int i = 0; i < 128; ++i)
    {
        if (head[i] == -1)
        {
            continue;
        }
        start[++b] = p;
        for (int j = head[i]; ~j; j = next[j])
        {
            rank[j] = b;
            sa[p++] = j;
        }
    }
    next[0] = 0;
    head[0] = sa[0];
    int len = 1;
    do
    {
        for (int i = 0; i <= n; ++i)
        {
            int j = sa[i] - len;
            if (j >= 0)
            {
                newsa[start[rank[j]]++] = j;
            }
        }
        for (int i = 1; i <= n; ++i)
        {
            sa[i] = newsa[i];
            int a = sa[i - 1], b = sa[i];
            bool cmp = rank[a] < rank[b] || rank[a] == rank[b] && rank[a + len] < rank[b + len];
            newrank[i] = newrank[i - 1] + cmp;
            if (cmp)
            {
                start[newrank[i]] = i;
            }
        }
        for (int i = 0; i <= n; ++i)
        {
            rank[sa[i]] = newrank[i];
        }
        len <<= 1;
    } while (newrank[n] != n);
    int cnt = 0;
    for (int i = 0; i < n; ++i)
    {
        int j = sa[rank[i] - 1];
        while (max(i, j) + cnt < n && s[i + cnt] == s[j + cnt])
        {
            ++cnt;
        }
        lcp[rank[i]] = cnt;
        if (cnt)
        {
            cnt--;
        }
    }
    int i = max_element(lcp.begin(), lcp.end()) - lcp.begin();
    cout << (lcp[i] ? s.substr(sa[i], lcp[i]) : "-1");

    return 0;
}
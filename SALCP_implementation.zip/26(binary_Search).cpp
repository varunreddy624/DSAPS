#define taskname "12"
#include <bits/stdc++.h>
#define int long long

using namespace std;
const int base = 31;
const int maxn = 1e5 + 10;
int H[maxn], mu[maxn], n;
string s, sans;

int calc(int l, int r) { return H[r] - H[l - 1] * mu[r - l + 1]; }

bool check(int val)
{
    unordered_set<int> us;
    for (int i = 1; i <= n - val + 1; i++)
    {
        int tmp = calc(i, i + val - 1);
        if (us.find(tmp) != us.end())
        {
            sans = s.substr(i - 1, val);
            return 1;
        }
        us.insert(tmp);
    }
    return 0;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> s;
    n = s.size();
    mu[0] = 1;
    for (int i = 1; i <= n; i++)
    {
        mu[i] = mu[i - 1] * base;
        H[i] = H[i - 1] * base + s[i - 1];
    }
    int lo = 1, hi = n, ans = -1;
    while (lo <= hi)
    {
        int mid = (lo + hi) >> 1;
        if (check(mid))
        {
            ans = mid;
            lo = mid + 1;
        }
        else
            hi = mid - 1;
    }
    if (ans != -1)
        cout << sans;
    else
        cout << ans;
}
#include <bits/stdc++.h>
#define fastio  \
    cin.tie(0); \
    ios_base::sync_with_stdio(0);
#define fs first
#define sc second

using namespace std;

vector<int> pos, rk, lcp;
int n;
void cntsr()
{
    vector<vector<int>> cnt(n);
    for (auto v : pos)
    {
        cnt[rk[v]].push_back(v);
    }
    for (int i = 0, idx = 0; i < n; i++)
    {
        for (auto x : cnt[i])
        {
            pos[idx] = x;
            idx++;
        }
    }
}
void sa(string s)
{
    s += char(30);
    n = s.length();
    rk.resize(n);
    pos.resize(n);
    lcp.resize(n);
    for (int i = 0; i < n; i++)
    {
        pos[i] = i;
    }
    sort(pos.begin(), pos.end(), [&](int a, int b)
         { return s[a] < s[b]; });
    rk[pos[0]] = 0;
    for (int i = 1; i < n; i++)
    {
        rk[pos[i]] = rk[pos[i - 1]] + (s[pos[i]] != s[pos[i - 1]]);
    }
    vector<int> nr(n);
    for (int k = 0; (1 << k) <= n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            pos[i] = (pos[i] + n - (1 << k)) % n;
        }
        cntsr();
        nr[pos[0]] = 0;
        for (int i = 1; i < n; i++)
        {
            pair<int, int> prev = {rk[pos[i - 1]], rk[(pos[i - 1] + (1 << k)) % n]};
            pair<int, int> nw = {rk[pos[i]], rk[(pos[i] + (1 << k)) % n]};
            nr[pos[i]] = nr[pos[i - 1]] + (prev != nw);
        }
        rk = nr;
    }
    int k = 0;
    for (int i = 0; i < n - 1; i++)
    {
        int pi = rk[i];
        int j = pos[pi - 1];
        while (i + k < n && j + k < n && s[i + k] == s[j + k])
        {
            k++;
        }
        lcp[pi] = k;
        k = max(0, k - 1);
    }
}
int main()
{
    fastio;
    string s;
    getline(cin, s);
    //cin >> s;
    sa(s);
    long long ans = 0;
    for (int i = 1; i < n; i++)
    {
        if (lcp[i] > lcp[ans])
        {
            ans = i;
        }
    }
    if (ans == 0)
    {
        cout << -1 << "\n";
        return 0;
    }
    for (int i = 0; i < lcp[ans]; i++)
    {
        cout << s[pos[ans] + i];
    }
    cout << "\n";
    return 0;
}
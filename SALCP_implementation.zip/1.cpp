/*
CLOCKS_PER_SEC 1000000
CPU-TIME START 4716
CPU-TIME END 140737353797632
CPU-TIME END - START 140737353792916
TIME(SEC) 1.40737e+08
*/

#include <bits/stdc++.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>
using namespace std;

#define WiwiHorz                      \
    ios_base::sync_with_stdio(false); \
    cin.tie(0);
#define endl '\n'

#define mp(a, b) make_pair(a, b)
#define F first
#define S second

#define FOR(i, a, b, c) for (int i = a; i < b; i += c)
#define REP(i, n) for (int i = 0; i < n; i++)
#define Each(i, v) for (auto &i : v)

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

template <typename T1, typename T2>
ostream &operator<<(ostream &os, pair<T1, T2> a)
{
    return os << "(" << a.first << ", " << a.second << ")";
}

/* -------------------------------------------------------------------- */

const int maxn = 1e5 + 2;
const int maxm = 5;
const int INF = 2e9;
const ll LLINF = 1e18;

struct suffixarray
{
    string s;
    int n;
    vector<int> suf, rk, cnt, pos;
    vector<ll> lcp;
    vector<pair<pii, int>> buc[2];
    void init(string &ss)
    {
        s = ss + (char)0;
        n = (int)s.size();
        suf.resize(n);
        rk.resize(n);
        lcp.resize(n, 0);
        cnt.resize(n);
        pos.resize(n);
        Each(i, buc) i.resize(n);
    }
    inline void radix_sort()
    {
        REP(t, 2)
        {
            fill(cnt.begin(), cnt.end(), 0);
            Each(i, buc[t]) cnt[(t ? i.F.F : i.F.S)]++;
            REP(i, n)
            pos[i] = i ? pos[i - 1] + cnt[i - 1] : 0;
            Each(i, buc[t]) buc[t ^ 1][pos[(t ? i.F.F : i.F.S)]++] = i;
        }
    }
    inline bool fill_suf()
    {
        REP(i, n)
        suf[i] = buc[0][i].S;
        rk[suf[0]] = 0;
        bool end = true;
        FOR(i, 1, n, 1)
        {
            bool dif = buc[0][i].F != buc[0][i - 1].F;
            end &= dif;
            rk[suf[i]] = rk[suf[i - 1]] + dif;
        }
        return end;
    }
    void buildSA()
    {
        REP(i, n)
        buc[0][i] = mp(mp(s[i], s[i]), i);
        sort(buc[0].begin(), buc[0].end());
        if (fill_suf())
            return;

        for (int k = 0; (1 << k) < n; k++)
        {
            REP(i, n)
            buc[0][i] = mp(mp(rk[i], rk[(i + (1 << k)) % n]), i);
            radix_sort();
            if (fill_suf())
                return;
        }
    }
    void buildLCP()
    {
        REP(i, n)
        {
            // building lcp[rk[i]]
            if (rk[i] == 0)
                continue;
            if (i)
                lcp[rk[i]] = max(0LL, lcp[rk[i - 1]] - 1);
            int j = suf[rk[i] - 1];
            while (i + lcp[rk[i]] < n && j + lcp[rk[i]] < n && s[i + lcp[rk[i]]] == s[j + lcp[rk[i]]])
                lcp[rk[i]]++;
        }
    }
};
suffixarray sa;

string s;
ll n;

void init()
{
    string s = "";
    srand(time(NULL));
    for (int i = 0; i < 10000; i++)
    {
        int a = rand() % 3;
        if (a == 0)
        {
            s += '0' + (rand() % 10);
        }
        else if (a == 1)
        {
            s += 'a' + (rand() % 26);
        }
        else if (a == 2)
        {
            s += 'A' + (rand() % 26);
        }
    }
    //cout << s;
    clock_t start, end;
    start = clock();
    //your code below
    //cin >> s;
    n = (ll)s.size();
    sa.init(s);
    sa.buildSA();
    // for (int i = 0; i < sa.suf.size(); i++)
    // {
    //     cout << sa.suf[i] << " ";
    // }

    cout << "CLOCKS_PER_SEC " << CLOCKS_PER_SEC << "\n";
    cout << "CPU-TIME START " << start << "\n";
    cout << "CPU-TIME END " << end << "\n";
    cout << "CPU-TIME END - START " << end - start << "\n";
    cout << "TIME(SEC) " << static_cast<double>(end - start) / CLOCKS_PER_SEC << "\n";

    //sa.buildLCP();
}

void solve()
{
    int pos, mx = 0;
    FOR(i, 1, n + 1, 1)
    {
        if (sa.lcp[i] > mx)
        {
            pos = sa.suf[i];
            mx = sa.lcp[i];
        }
    }
    if (mx == 0)
        return cout << -1 << endl, void();
    while (mx--)
        cout << s[pos++];
    cout << endl;
}

int main()
{
    WiwiHorz

    init();
    solve();

    return 0;
}
#include <bits/stdc++.h>

using namespace std;
typedef long long int i64;

struct suffix
{
    int f, s, i;
    suffix() {}
    suffix(int f, int s, int i) : f(f), s(s), i(i) {}
    operator int()
    {
        return i;
    }
};

vector<int> suffix_array(string s)
{
    string t = s + '$';
    int n = t.size();
    vector<suffix> sa(n);
    vector<pair<int, int>> rs(n);
    for (int i = 0; i < n; i++)
        sa[i] = suffix(t[i] - 'a', t[i + 1] - 'a', i);
    for (int i = 1; i <= int(log2(n) + 1); i++)
    {
        sort(sa.begin(), sa.end(), [](auto a, auto b)
             { return a.f == b.f ? a.s < b.s : a.f < b.f; });
        for (int j = 0, rank = 0; j < n; j++)
        {
            if (j != 0)
                rank += (sa[j - 1].f != sa[j].f || sa[j - 1].s != sa[j].s);
            rs[sa[j].i] = make_pair(j, rank);
        }
        for (int j = 0, of = 1 << i; j < n; j++)
        {
            int k = sa[j].i;
            sa[j].f = rs[k].second;
            sa[j].s = k + of < n ? rs[k + of].second : rs[n - 1].second;
        }
    }
    vector<int> res(sa.begin() + 1, sa.end());
    return res;
}

vector<int> lcp_array(vector<int> &sa, string &s)
{
    int n = sa.size();
    vector<int> rs(n), lcp(n);
    for (int i = 0; i < n; i++)
        rs[sa[i]] = i;
    for (int i = 0, h = 0; i < n; i++)
    {
        if (rs[i] > 0)
        {
            int k = sa[rs[i] - 1];
            while (i + h < n && k + h < n && s[i + h] == s[k + h])
            {
                h++;
            }
            lcp[rs[i]] = h;
            if (h > 0)
                h -= 1;
        }
    }
    return lcp;
}

int main()
{
    string s;
    cin >> s;
    vector<int> sa = suffix_array(s);
    vector<int> lcp = lcp_array(sa, s);
    int mx = 0, mxi = -1;
    for (int i = 0; i < s.size(); i++)
    {
        if (lcp[i] > mx)
        {
            mx = lcp[i];
            mxi = i;
        }
    }
    if (mx == 0)
        cout << -1 << endl;
    else
        cout << s.substr(sa[mxi], mx) << endl;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define endl '\n'

const int mxN = 1e5 + 5;
ll sa[mxN], pos[mxN], tmp[mxN], lcp[mxN];
int gap, N;
string S;

bool comp(int x, int y)
{
    if (pos[x] != pos[y])
        return pos[x] < pos[y];
    x += gap;
    y += gap;
    return (x < N && y < N) ? pos[x] < pos[y] : x > y;
}

void suffix()
{
    for (int i = 0; i < N; i++)
        sa[i] = i, pos[i] = S[i];

    for (gap = 1;; gap <<= 1)
    {
        sort(sa, sa + N, comp);
        for (int i = 0; i < N - 1; i++)
            tmp[i + 1] = tmp[i] + comp(sa[i], sa[i + 1]);
        for (int i = 0; i < N; i++)
            pos[sa[i]] = tmp[i];
        if (tmp[N - 1] == N - 1)
            break;
    }
}

void buildLCP()
{

    for (int i = 0, k = 0; i < N; i++)
        if (pos[i] != N - 1)
        {
            int j = sa[pos[i] + 1];
            while (S[i + k] == S[j + k])
                k++;
            lcp[pos[i]] = k;
            if (k)
                k--;
        }
    for (int j = N - 2; j >= 0; j--)
    {
        lcp[j + 1] = lcp[j];
    }
    lcp[0] = 0;
}
int main()
{

    cin >> S;

    N = S.size();
    suffix();
    buildLCP();
    //   for(int i=0;i<N;i++)
    //   cout<<sa[i]<<" ";
    //  cout<<endl;
    // for(int i=0;i<N;i++)
    // cout<<lcp[i]<<" ";
    //  return 0;
    ll st = -1, max1 = 0;

    for (int j = 0; j < N; j++)
    {
        if (max1 < lcp[j])
        {
            max1 = lcp[j];
            st = sa[j];
        }
    }
    if (st != -1)
        cout << S.substr(st, max1);
    else
        cout << "-1";
}
#include <string>
#include <utility>
#pragma GCC optimize("O3")
#pragma GCC target("sse4")

#include <bits/stdc++.h>
//gouravrj code:P
using namespace std;
#define fo(i, n) for (int i = 0; i < n; i++)
#define Fo(i, k, n) for (int i = k; k < n ? i < n : i > n; k < n ? i += 1 : i -= 1)
#define ll long long
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define sz(x) (int)x.size()
#define all(x) x.begin(), x.end()
#define tr(it, a) for (auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
#define INF 0x3f3f3f3f3f3f3f3fLL
typedef pair<int, int> pii;
typedef pair<ll, ll> pl;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpii;
typedef vector<pl> vpl;
typedef vector<vi> vvi;
typedef vector<vl> vvl;
const int mod = 1000000007;
const int N = 3e5, M = N;
/*******************************************************************************************/
template <typename T>
ostream &operator<<(ostream &os, const vector<T> &v)
{
    os << "[";
    for (int i = 0; i < v.size(); ++i)
    {
        if (i)
            os << ", ";
        os << v[i];
    }
    os << "]\n";
    return os;
}
template <typename T>
ostream &operator<<(ostream &os, const set<T> &v)
{
    os << "{";
    for (auto it : v)
    {
        os << it;
        if (it != *v.rbegin())
            os << ", ";
    }
    os << "}\n";
    return os;
}
template <typename T>
ostream &operator<<(ostream &os, const multiset<T> &v)
{
    os << "{";
    for (auto it : v)
    {
        os << it;
        if (it != *v.rbegin())
            os << ", ";
    }
    os << "}\n";
    return os;
}
template <typename T, typename S>
ostream &operator<<(ostream &os, const map<T, S> &v)
{
    os << "{";
    for (auto it : v)
    {
        os << "(" << it.first << " : " << it.second << ")";
        if (it != *v.rbegin())
            os << ", ";
    }
    os << "}\n";
    return os;
}
template <typename T, typename S>
ostream &operator<<(ostream &os, const unordered_map<T, S> &v)
{
    os << "{";
    for (auto it : v)
    {
        os << "(" << it.first << " : " << it.second << ")";
        os << ", ";
    }
    os << "}\n";
    return os;
}
template <typename T, typename S>
ostream &operator<<(ostream &os, const pair<T, S> &v)
{
    os << "(";
    os << v.first << ", " << v.second << ")";
    return os;
}
template <typename T>
inline istream &operator>>(istream &in, vector<T> &a)
{
    for (auto &x : a)
        in >> x;
    return in;
}
#ifndef ONLINE_JUDGE
const string COLOR_RESET = "\033[0m", BRIGHT_GREEN = "\033[1;32m", BRIGHT_RED = "\033[0;31m", BRIGHT_CYAN = "\033[1;36m";
vector<string> tokenizer(const string args)
{
    string tk = args;
    vector<string> v;
    for (int i = 0; i < tk.size(); i++)
    {
        string s = "";
        int j = i;
        while (j < tk.size() && tk[j] != ',')
            s += tk[j++];
        i = j;
        v.push_back(s);
    }
    reverse(all(v));
    return v;
}
void debugg(vector<string> args) { cerr << "\b\b "; }
template <typename Head, typename... Tail>
void debugg(vector<string> args, Head H, Tail... T)
{
    if (!sz(args))
        return;
    cerr << " [" << BRIGHT_CYAN << args.back() << ": " << BRIGHT_GREEN << H << COLOR_RESET << "] ";
    if (sz(args))
    {
        args.pop_back();
        debugg(args, T...);
    }
}
#define deb(...)                                                \
    {                                                           \
        debugg(tokenizer(#__VA_ARGS__), __VA_ARGS__, __LINE__); \
        cerr << '\n';                                           \
    }
#endif
#ifdef ONLINE_JUDGE
#define deb(...)
#endif

/*******************************************************************************************/

vector<int> prefFunc(string s)
{
    vector<int> pi(s.size());

    for (int i = 1; i < s.size(); i++)
    {
        int j = pi[i - 1];
        while (j > 0 && s[i] != s[j])
            j = pi[j - 1];
        if (s[i] == s[j])
            j++;
        pi[i] = j;
    }

    return pi;
}
vector<int> Zfunc(string s)
{
    int n = s.size();
    s += '#';
    vector<int> ans(n, 0);
    ans[0] = n;
    if (n == 1)
        return ans;
    while (s[ans[1]] == s[ans[1] + 1])
        ans[1]++;
    int l = 1;
    int hi = ans[1];
    for (int i = 2; i < n; i++)
    {
        if (i <= hi)
            ans[i] = min(hi - i + 1, ans[i - l]);
        while (s[ans[i] + i] == s[ans[i]])
            ans[i]++;
        if (ans[i] + i - 1 > hi)
        {
            l = i;
            hi = ans[i] + i - 1;
        }
    }
    ans[0] = 0;
    return ans;
}
struct Suffarry
{
    struct suf
    {
        int idx, rnk[2];
    };
    static bool cmp(suf a, suf b)
    {
        if (a.rnk[0] == b.rnk[0])
            return a.rnk[1] < b.rnk[1];
        else
            return a.rnk[0] < b.rnk[0];
    }
    vector<int> buildSa(string const &s)
    {
        int n = s.size();
        vector<suf> res(n);
        fo(i, n)
        {
            res[i].idx = i;
            res[i].rnk[0] = s[i] - 'a';
            res[i].rnk[1] = ((i + 1) < n) ? (s[i + 1] - 'a') : 1;
        }
        sort(all(res), cmp);
        int ind[n];
        for (int k = 4; k < 2 * n; k *= 2)
        {
            int rnk = 0;
            int pr = res[0].rnk[0];
            res[0].rnk[0] = 0;
            ind[res[0].idx] = 0;
            Fo(i, 1, n)
            {
                if (res[i].rnk[0] == pr && res[i].rnk[1] == res[i - 1].rnk[1])
                {
                    pr = res[i].rnk[0];
                    res[i].rnk[0] = rnk;
                }
                else
                {
                    pr = res[i].rnk[0];
                    res[i].rnk[0] = ++rnk;
                }
                ind[res[i].idx] = i;
            }
            for (int i = 0; i < n; i++)
            {
                int nxidx = res[i].idx + k / 2;
                res[i].rnk[1] = (nxidx < n) ? res[ind[nxidx]].rnk[0] : -1;
            }
            sort(all(res), cmp);
        }
        vector<int> sa;
        fo(i, n) sa.pb(res[i].idx);
        return sa;
    }
    vector<int> lcp(string s, vector<int> sa)
    {
        int n = s.size();
        vector<int> lcp(n, 0), invsa(n, 0);
        fo(i, n) invsa[sa[i]] = i;
        int k = 0;
        fo(i, n)
        {
            if (invsa[i] == n - 1)
            {
                k = 0;
                continue;
            }
            int j = sa[invsa[i] + 1];
            while (i + k < n && j + k < n && s[i + k] == s[j + k])
                k++;
            lcp[invsa[i]] = k;
            if (k > 0)
                k--;
        }
        return lcp;
    }
};
Suffarry S;
void run_case()
{
    ll int t, i, j, k, p, x, y, u, n, m, w;

    string s;
    cin >> s;
    auto sa = S.buildSa(s);
    auto v = S.lcp(s, sa);
    int pos = -1;
    int mx = 0;
    fo(i, sz(v))
    {
        if (v[i] > mx)
        {
            mx = v[i];
            pos = i;
        }
    }
    if (pos == -1)
    {
        cout << -1;
    }
    else
    {
        cout << s.substr(sa[pos], mx) << endl;
    }
}

/*******************************************************************************************/

int main()
{
    cin.tie(0)->sync_with_stdio(0);
#ifndef ONLINE_JUDGE
    freopen("/home/gourav/input1.txt", "r", stdin);
    freopen("/home/gourav/output1.txt", "w", stdout);
    //freopen("error.txt", "w", stderr);
#endif
    int t = 1;
    //int T;
    Fo(T, 1, t + 1)
    {
        // cout<<"Case #"<<T<<": ";
        run_case();
    }
    //cerr << "time taken : " << (float)clock() / CLOCKS_PER_SEC << " secs" << endl;
    return 0;
}
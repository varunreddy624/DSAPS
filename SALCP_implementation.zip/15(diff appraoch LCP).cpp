#include <bits/stdc++.h>
#define ll long long
#define loop(i, a, b) for (ll i = a; i < b; ++i)
#define pool(i, a, b) for (ll i = a - 1; i >= b; --i)
#define fore(i, a) for (auto &&i : a)
#define fi first
#define se second
#define ps(a) push_back(a)
#define pb(a) pop_back(a)
#define eb(...) emplace_back(__VA_ARGS__)
#define sc scanf
#define vc vector
#define lb lower_bound
#define ub upper_bound
#define all(a) a.begin(), a.end()
#define llmax LLONG_MAX / 2
#define llmin -LLONG_MAX / 2
using namespace std;
#define mn 61
#define par pair<ll, ll>
#define ld long double
#define mod 1000000007
struct srt
{
    ll n, d;
    vc<vc<ll>> val;

    srt(string s = "")
    {
        n = s.size();
        d = 1;

        vc<vc<ll>> srtal(27);
        loop(i, 0, n) srtal[s[i] - 'a'].ps(i);

        loop(i, 0, 27) if (srtal[i].size()) val.ps(srtal[i]);
    }

    srt operator+(srt &oth)
    {
        srt ret;
        ret.n = n;
        ret.d = d + oth.d;

        vc<ll> p(n);
        loop(j, 0, val.size()) fore(v, val[j]) p[v] = j;

        vc<vc<par>> preval(val.size());

        loop(j, 0, oth.val.size()) fore(v, oth.val[j])
        {
            ll t = v - d;
            while (t < 0)
                t += n;

            preval[p[t]].eb(j, t);
        }

        fore(u, preval)
        {
            ret.val.ps((vc<ll>{}));
            ll las = -1;
            fore(v, u)
            {
                if (las != -1 and las != v.fi)
                    ret.val.ps((vc<ll>{}));

                ret.val.back().ps(v.se);
                las = v.fi;
            }
        }

        return ret;
    }

    bool isok()
    {
        fore(v, val) if (v.size() >= 2) return true;
        return false;
    }
};

int main()
{
    string s;
    cin >> s;
    s += (char)('a' + 26);
    ll n = s.size();

    srt ans;
    ans.n = n;
    ans.d = 0;
    ans.val.ps((vc<ll>{}));
    loop(i, 0, n) ans.val[0].ps(i);

    srt bas(s);
    vc<srt> dp;
    dp.ps(bas);
    loop(i, 1, 20) dp.ps(dp[i - 1] + dp[i - 1]);
    pool(i, 20, 0) if ((ans + dp[i]).isok()) ans = ans + dp[i];

    if (ans.d)
    {
        fore(v, ans.val) if (v.size() >= 2)
        {
            ll st = v[0];
            cout << s.substr(st, ans.d) << endl;
            break;
        }
    }
    else
        cout << -1 << endl;
}
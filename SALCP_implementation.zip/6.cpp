#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
typedef long long li;

struct SuffixArray
{
    int n;
    vector<int> p, p_next, ceq, ceq_next, cnt, pos, lcp;
    string s;

    SuffixArray(int _n) : n(_n + 1), p(n), p_next(n), ceq(n), ceq_next(n), cnt(n), pos(n), lcp(n) {}

    void Build()
    {
        std::iota(p.begin(), p.end(), 0);
        std::sort(p.begin(), p.end(), [this](int i, int j)
                  { return s[i] < s[j]; });

        for (int i = 1; i < n; i++)
        {
            if (s[p[i]] == s[p[i - 1]])
                ceq[p[i]] = ceq[p[i - 1]];
            else
                ceq[p[i]] = ceq[p[i - 1]] + 1;
        }

        for (int k = 0; (1 << k) < n; k++)
        {
            for (int i = 0; i < n; i++)
                p[i] = (p[i] - (1 << k) + n) % n;
            std::fill(cnt.begin(), cnt.end(), 0);
            for (auto &x : ceq)
                cnt[x]++;
            pos[0] = 0;
            for (int i = 1; i < n; i++)
                pos[i] = pos[i - 1] + cnt[i - 1];
            for (auto &x : p)
            {
                int id = ceq[x];
                p_next[pos[id]] = x;
                pos[id]++;
            }
            swap(p, p_next);
            ceq_next[p[0]] = 0;
            for (int i = 1; i < n; i++)
            {
                pair<int, int> prev = {ceq[p[i - 1]], ceq[(p[i - 1] + (1 << k)) % n]};
                pair<int, int> cur = {ceq[p[i]], ceq[(p[i] + (1 << k)) % n]};
                if (prev == cur)
                    ceq_next[p[i]] = ceq_next[p[i - 1]];
                else
                    ceq_next[p[i]] = ceq_next[p[i - 1]] + 1;
            }
            swap(ceq, ceq_next);
        }
    }

    void CalculateLCP()
    {
        int k = 0;
        for (int i = 0; i + 1 < n; i++)
        {
            int pi = ceq[i];
            int j = p[pi - 1];
            while (s[k + i] == s[j + k])
                k++;
            lcp[pi] = k;
            k = max(0, k - 1);
        }
    }

    void Init(string _s)
    {
        s = _s + "#";
        Build();
        CalculateLCP();
    }

    string FindRepeatingSubstring()
    {
        int maxPos = 0;
        for (int i = 0; i < n; i++)
            if (lcp[i] > lcp[maxPos])
                maxPos = i;
        if (lcp[maxPos] == 0)
            return "-1";
        return s.substr(p[maxPos], lcp[maxPos]);
    }
};

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    string s, t;

    cin >> s;
    SuffixArray sa(s.size());
    sa.Init(s);
    cout << sa.FindRepeatingSubstring();
    return 0;
}
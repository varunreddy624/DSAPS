#include <bits/stdc++.h>

using namespace std;

string max_repeating_suffix_array(string s)
{
    s.push_back('$');
    int n = (int)s.size();
    vector<int> p(n), c(n);

    {
        vector<pair<char, int>> a(n);
        for (int i = 0; i < n; i++)
            a[i] = {s[i], i};
        sort(a.begin(), a.end());
        for (int i = 0; i < n; i++)
            p[i] = a[i].second;
        c[p[0]] = 0;
        for (int i = 1; i < n; i++)
        {
            if (a[i].first == a[i - 1].first)
                c[p[i]] = c[p[i - 1]];
            else
                c[p[i]] = c[p[i - 1]] + 1;
        }
    }

    for (int k = 0; (1 << k) < n; k++)
    {
        vector<pair<pair<int, int>, int>> a(n);
        for (int i = 0; i < n; i++)
            a[i] = {{c[i], c[(i + (1 << k)) % n]}, i};
        sort(a.begin(), a.end());
        for (int i = 0; i < n; i++)
            p[i] = a[i].second;
        c[p[0]] = 0;
        for (int i = 1; i < n; i++)
        {
            if (a[i].first == a[i - 1].first)
                c[p[i]] = c[p[i - 1]];
            else
                c[p[i]] = c[p[i - 1]] + 1;
        }
    }

    vector<int> lcp(n);
    int k = 0;
    for (int i = 0; i + 1 < n; i++)
    {
        int j = p[c[i] - 1];
        while (s[i + k] == s[j + k])
            k++;
        lcp[c[i]] = k;
        k = max(k - 1, 0);
    }

    int len = 0, pos = -1;
    for (int i = 1; i < n; i++)
    {
        if (lcp[i] > len)
        {
            len = lcp[i];
            pos = i;
        }
    }
    if (len == 0)
        return "-1";
    else
        return s.substr(p[pos], len);
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie();

    string s;
    cin >> s;
    cout << max_repeating_suffix_array(s) << '\n';

    return 0;
}
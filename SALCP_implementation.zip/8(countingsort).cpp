#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define FASTIO                        \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);                    \
    cout.tie(NULL);

void counting_sort(int k, vector<int> &sa, const vector<int> &ra)
{
    int maxi = max(static_cast<int>(sa.size()), 300);
    vector<int> c(maxi);
    for (int i = 0; i < sa.size(); i++)
    {
        c[((i + k) < sa.size()) ? ra[i + k] : 0]++;
    }
    vector<int> tmp_sa(sa.size());
    int t = 0;
    int sum = 0;
    for (int i = 0; i < maxi; i++)
    {
        t = c[i];
        c[i] = sum;
        sum += t;
    }
    for (int i = 0; i < sa.size(); i++)
    {
        tmp_sa[c[((sa[i] + k) < sa.size()) ? ra[sa[i] + k] : 0]++] = sa[i];
    }
    swap(tmp_sa, sa);
}
void construct_sa(vector<int> &sa, vector<int> &ra, const string &str)
{
    for (int i = 0; i < str.size(); i++)
    {
        ra[i] = str[i];
        sa[i] = i;
    }
    for (int k = 1; k < str.size(); k *= 2)
    {
        counting_sort(k, sa, ra);
        counting_sort(0, sa, ra);
        int r = 0;
        vector<int> tmp_ra(str.size());
        tmp_ra[sa[0]] = 0;
        for (int i = 1; i < str.size(); i++)
        {
            if (ra[sa[i]] == ra[sa[i - 1]] && ra[sa[i] + k] == ra[sa[i - 1] + k])
            {
                tmp_ra[sa[i]] = r;
            }
            else
            {
                tmp_ra[sa[i]] = ++r;
            }
        }
        if (r == str.size() - 1)
        {
            break;
        }
        swap(ra, tmp_ra);
    }
}
void computeLCP(const vector<int> &sa, const string &str, vector<int> &lcp)
{
    vector<int> phi(sa.size());
    vector<int> plcp(sa.size());
    phi[sa[0]] = -1;
    for (int i = 1; i < str.size(); i++)
    {
        phi[sa[i]] = sa[i - 1];
    }
    int l = 0;
    for (int i = 0; i < str.size(); i++)
    {
        if (phi[i] == -1)
        {
            l = 0;
            continue;
        }
        while (str[i + l] == str[phi[i] + l])
        {
            l++;
        }
        plcp[i] = l;
        l = max(l - 1, 0);
    }
    for (int i = 0; i < str.size(); i++)
    {
        lcp[i] = plcp[sa[i]];
    }
}

bool istrue(int mid, int a, int b)
{
    return (mid > a && mid < b || mid < a && mid > b);
}
int main()
{
    FASTIO;
    string s;
    cin >> s;
    s.push_back('#');
    vector<int> sa(s.length(), 0);
    vector<int> ra(s.length(), 0);
    vector<int> lcp(s.length(), 0);
    construct_sa(sa, ra, s);
    computeLCP(sa, s, lcp);
    int mxlen = 0, midx = -1;
    for (int i = 0; i < s.length(); i++)
    {
        if (lcp[i] > mxlen)
        {
            mxlen = lcp[i];
            midx = sa[i];
        }
    }
    if (midx == -1)
        cout << -1 << endl;
    else
        cout << s.substr(midx, mxlen) << endl;
    return 0;
}
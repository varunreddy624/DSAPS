#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;

#define FOR(x, a, b) for (int x = a; x <= b; x++)
#define VOR(x, b, a) for (int x = b; x >= a; x--)

vector<int> get_sa(string s)
{
    s += " ";
    int n = s.size(), csiz = max(256, n);
    vector<int> pos(n), rnk(n), cnt(csiz);
    FOR(i, 0, n - 1)
    cnt[s[i]]++;
    FOR(i, 1, csiz - 1)
    cnt[i] += cnt[i - 1];
    FOR(i, 0, n - 1)
    pos[--cnt[s[i]]] = i;
    rnk[pos[0]] = 0;
    int now = 0;
    FOR(i, 1, n - 1)
    {
        now += (s[pos[i]] != s[pos[i - 1]]);
        rnk[pos[i]] = now;
    }
    for (int len = 1; len < n; len <<= 1)
    {
        vector<int> lp(n), new_rnk(n);
        FOR(i, 0, n - 1)
        {
            lp[i] = pos[i] - len;
            if (lp[i] < 0)
                lp[i] += n;
        }
        fill(cnt.begin(), cnt.end(), 0);
        FOR(i, 0, n - 1)
        cnt[rnk[lp[i]]]++;
        FOR(i, 1, csiz - 1)
        cnt[i] += cnt[i - 1];
        VOR(i, n - 1, 0)
        pos[--cnt[rnk[lp[i]]]] = lp[i];
        now = new_rnk[pos[0]] = 0;
        FOR(i, 1, n - 1)
        {
            pair<int, int> p1, p0;
            p1 = {rnk[pos[i]], rnk[(pos[i] + len) % n]};
            p0 = {rnk[pos[i - 1]], rnk[(pos[i - 1] + len) % n]};
            now += (p1 != p0);
            new_rnk[pos[i]] = now;
        }
        rnk = new_rnk;
    }
    pos.erase(pos.begin());
    return pos;
}

vector<int> get_lcp(vector<int> pos, string s)
{
    int n = s.size(), k = 0;
    vector<int> rnk(n), lcp(n - 1);
    FOR(i, 0, n - 1)
    rnk[pos[i]] = i;
    FOR(i, 0, n - 1)
    {
        if (rnk[i] == n - 1)
        {
            k = 0;
            continue;
        }
        int j = pos[rnk[i] + 1];
        while (i + k < n && j + k < n && s[i + k] == s[j + k])
            k++;
        lcp[rnk[i]] = k;
        k -= (k != 0);
    }
    return lcp;
}

void solve()
{
    string str;
    cin >> str;
    vector<int> sa = get_sa(str), lcp = get_lcp(sa, str);

    int mxl = 0, pos;
    FOR(i, 0, str.size() - 2)
    {
        int len = lcp[i], p1 = sa[i], p2 = sa[i + 1];
        if (p1 > p2)
            swap(p1, p2);
        if (len > mxl)
        {
            mxl = len;
            pos = p1;
        }
    }

    if (mxl == 0)
        cout << "-1\n";
    else
        cout << str.substr(pos, mxl) << '\n';
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0);
    solve();
}
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define HarryPotter               \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);
#define ll long long
#define mk make_pair
#define ff first
#define ss second
#define debug(x) cout << #x << " :: " << x << "\n";
#define debug2(x, y) cout << #x << " :: " << x << "\t" << #y << " :: " << y << "\n";
#define debug3(x, y, z) cout << #x << " :: " << x << "\t" << #y << " :: " << y << "\t" << #z << " :: " << z << "\n";
#define in_range(x, y, r, c) (x < r && y < c && x >= 0 && y >= 0)

template <typename T>
void prll_vector(vector<T> path)
{
    copy(path.begin(), path.end(), ostream_iterator<T>(cout, " "));
    cout << endl;
}
template <typename T>
void prll_array(T a, ll n)
{
    for (ll i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
}

vector<ll> take_input(ll n)
{
    vector<ll> v(n);
    for (ll i = 0; i < n; i++)
        cin >> v[i];
    return v;
}

const ll MAXN = 1e6 + 1;
typedef unsigned long long hash1;
const hash1 BASE = 137;
ll N;
ll sa[MAXN], pos[MAXN], tmp[MAXN], lcp[MAXN];
hash1 h[MAXN], hPow[MAXN];
string S;
#define getHash(lo, size) (h[lo] - h[(lo) + (size)] * hPow[size])

bool sufCmp(ll i, ll j)
{
    ll lo = 1, hi = min(N - i, N - j);
    while (lo <= hi)
    {
        ll mid = (lo + hi) >> 1;
        // debug3( lo , hi , mid );
        if (getHash(i, mid) == getHash(j, mid))
            lo = mid + 1;
        else
            hi = mid - 1;
        // debug3( lo , hi , mid );
    }
    return S[i + hi] < S[j + hi];
}

void buildSA()
{
    N = S.length();
    hPow[0] = 1;
    for (ll i = 1; i <= N; ++i)
        hPow[i] = hPow[i - 1] * BASE;

    h[N] = 0;
    for (ll i = N - 1; i >= 0; --i)
        h[i] = h[i + 1] * BASE + S[i], sa[i] = i;
    stable_sort(sa, sa + N, sufCmp);
}

void buildLCP()
{
    for (ll i = 1; i < N; i++)
    {
        ll k = 0, l = 1, r = N;
        while (l <= r)
        {
            ll len = (l + r) / 2;
            if (getHash(sa[i], len) == getHash(sa[i - 1], len))
            {
                k = len;
                l = len + 1;
            }
            else
            {
                r = len - 1;
            }
        }

        lcp[i] = k;
    }
}

int main()
{
    HarryPotter;
    ll test;
    test = 1;

    while (test--)
    {
        cin >> S;
        buildSA();
        buildLCP();

        ll ans = 0;

        ll idx = -1;

        for (ll i = 0; i < N; i++)
        {
            if (ans < lcp[i])
            {
                ans = lcp[i];
                idx = i;
            }
        }

        string a;

        for (int i = sa[idx]; i <= sa[idx] + ans - 1; i++)
            a += S[i];

        if (a.length() != 0)
            cout << a << "\n";
        else
            cout << -1 << endl;
    }

    return 0;
}
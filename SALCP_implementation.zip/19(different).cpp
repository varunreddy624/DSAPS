#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;

// Heavily inspired by https://github.com/mrsac7/CSES-Solutions/blob/master/src/2110%20-%20Substring%20Distribution.cpp
int sa[N], lcp[N], rnk[N], tmp[N];

void build_lcp(const string &s)
{
    int n = s.size();
    for (int i = 0, k = 0; i < n; i++)
        if (rnk[i] != n - 1)
        {
            int j = sa[rnk[i] + 1];
            while (s[i + k] == s[j + k])
                k++;
            lcp[rnk[i]] = k;
            if (k)
                k--;
        }
}

void suffix_array(const string &s)
{
    int n = s.size();
    int gap;

    auto lt = [&](int i, int j)
    {
        if (rnk[i] != rnk[j])
            return rnk[i] < rnk[j];
        i += gap;
        j += gap;
        return i < n && j < n ? rnk[i] < rnk[j] : i > j;
    };

    for (int i = 0; i < n; i++)
        sa[i] = i, rnk[i] = s[i];

    for (gap = 1;; gap *= 2)
    {
        sort(sa, sa + n, lt);
        for (int i = 1; i < n; i++)
            tmp[i] = tmp[i - 1] + lt(sa[i - 1], sa[i]);
        for (int i = 0; i < n; i++)
            rnk[sa[i]] = tmp[i];
        if (tmp[n - 1] == n - 1)
            break;
    }
    build_lcp(s);
}

int main()
{
    cin.tie(0)->sync_with_stdio(false);

    string s;
    cin >> s;
    suffix_array(s);

    int n = s.size();
    int sz = 0;
    int where = 0;
    for (int i = 0; i < n; i++)
    {
        if (lcp[i] > sz)
        {
            sz = lcp[i];
            where = sa[i];
        }
    }

    if (sz == 0)
    {
        cout << -1 << '\n';
        return 0;
    }

    for (int i = 0; i < sz; i++)
        cout << s[where + i];
    cout << '\n';

    return 0;
}